# 🚆 AI Job Hunter — Kişisel İş İlanı Takip Ajanı

📱 **Telefonda (Xiaomi Redmi 10 / MIUI 14 / Android 14) çalıştırmak için: `README_ANDROID.md`** — bilgisayar kurulumu için aşağıdaki Bölüm 3'ü izleyin.

TCDD / TCDD Taşımacılık öncelikli, KPSS önlisans (P93) profiline göre ilanları izleyen, **kural tabanlı + isteğe bağlı Claude** ile analiz eden, SQLite'a kaydeden ve Telegram'dan bildiren sistem. **Başvuru asla otomatik yapılmaz.**

## 0. DÜRÜST DURUM RAPORU (önce bunu okuyun)

| Konu | Durum |
|---|---|
| Çekirdek (analiz, puanlama, veritabanı, bildirim mantığı, tekrar önleme, güncelleme tespiti) | ✅ 17 otomatik testle doğrulandı (internet gerektirmez) |
| **Canlı kaynak entegrasyonları** | ⚠️ **Geliştirme ortamında internet erişimim yoktu; hiçbir siteye gerçek bağlantı denenmedi.** Kaynaklar `sources.json` içinde **kapalı ve "doğrulanmadı"** olarak gelir. |
| Telegram gönderimi | Kod hazır, hata/yeniden deneme testli (taklit ile). Gerçek bot ile ilk denemeyi siz yapacaksınız. |
| Claude API | Kod hazır, şema + halüsinasyon korumalı; gerçek API anahtarıyla denenmedi. Anahtarsız da çalışır. |
| n8n workflow | JSON geçerli; n8n içinde **içe aktarılıp denenmedi**. |
| `panel.py` | Derleniyor; Streamlit kurulu olmadığı için **çalıştırılmadı**. |

**Araştırmada öğrendiklerim (haber/ikincil kaynaklardan, resmî teyit değil):**
- KPSS-2026/2 tercih kılavuzu Kasım 2026 ortası itibarıyla yayımlanmamış görünüyor; haberlerde tercih tarihi **17–24 Aralık 2026** olarak geçiyor. Kılavuz çıkınca **nitelik kodlarını ÖSYM PDF'inden siz doğrulayın**.
- Raylı Sistemler Elektrik-Elektronik için ikincil bir sitede **3206** kodu geçiyor; `3001` genel önlisans kodu olarak biliniyor. İkisi de **resmî kılavuzdan doğrulanmadığı için** `.env` içinde `QUAL_CODES_VERIFIED=false` geliyor. Bu durumda sistem "Şartları karşılıyor" demez, en fazla "Muhtemelen karşılıyor" der.
- TCDD/TCDD Taşımacılık ilanlarındaki "Memur" unvanlı kadroların bir kısmı kılavuzda "KİT sözleşmeli personel" sınıfında görünüyor. Sınıfı ilan/kılavuzdan kontrol edin.
- **Kariyer Kapısı** e-Devlet girişi gerektirir; oturum korumasını aşmak yasak/uygunsuz olduğundan otomatik taranmaz. ÖSYM kılavuz duyurularını ve kurum duyurularını izleyin; Kariyer Kapısı için e-posta/Telegram hatırlatması dışında otomasyon yoktur.
- **ilan.gov.tr**'nin belgelenmiş resmî API'sini bulamadım; topluluk projelerinde sitenin iç JSON uç noktası kullanılıyor. Bu yüzden `ENABLE_ILAN_GOV=false` (varsayılan kapalı). Açmadan önce kullanım koşullarını/robots.txt'yi kontrol edin.

## 1. Mimari

```
 Zamanlayıcı (n8n / Görev Zamanlayıcı / cron)  ──►  python main.py --once
                                                         │
   sources/ (RSS, HTML liste, [ilan.gov.tr deneysel])    │  robots.txt + hız sınırı + yeniden deneme
        │  ilan listesi + detay sayfası/PDF metni         ▼
        └──────────────────────────────►  database.py (SQLite)  ── eşleştirme: kaynak-id → parmak izi → benzer başlık
                                                         │
                         analyzer.py: 1) regex çıkarım  2) (ops.) Claude JSON  3) kod/tarih doğrulama  4) deterministik puan
                                                         │
                         notifier.py: Telegram (3 deneme) → olmazsa e-posta;  başarısızsa sonraki turda tekrar denenir
                                                         ▼
                         panel.py (Streamlit)  •  haftalık özet  •  hata uyarısı (n8n)
```

Dosyalar: `main.py`, `analyzer.py`, `database.py`, `notifier.py`, `config.py`, `sources/`, `sources.json`, `tests/`, `workflow.json`, `panel.py`, `get_chat_id.py`, `.env.example`, `requirements.txt`.

## 2. Puanlama (0–100)
Mezuniyet/nitelik 30 · KPSS 20 · Kurum/kadro 20 · Askerlik-yaş-diğer 15 · Konum 10 · Süre 5.
**Puan ve durum ayrıdır.** Engel varsa (puan yetersiz, süre geçmiş, lisans şartı, kod uyuşmazlığı…) puan yüksek olsa da durum "Şartları karşılamıyor". Belirsizlik varsa "Ek doğrulama gerekli". Askerlik tek başına engel sayılmaz. Emniyet-kritik görevler (makinist, trafik, hareket vb.) ayrıca işaretlenir; sağlık uygunluğu hakkında hüküm verilmez.

## 3. Kurulum (Windows, adım adım)

1. **Python:** https://www.python.org/downloads/ → indirin → kurulumda **"Add python.exe to PATH"** kutusunu işaretleyin.
2. Bu zip'i `C:\ai_job_hunter` klasörüne çıkarın.
3. Başlat'a "PowerShell" yazıp açın ve sırayla çalıştırın:
   ```powershell
   cd C:\ai_job_hunter
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   copy .env.example .env
   notepad .env
   ```
4. **Deneme (internetsiz):** `python main.py --demo --dry-run --no-llm` → örnek (uydurma) ilanlar için ekranda bildirim görürsünüz.
5. **Testler:** `python -m unittest discover -s tests -v` → `OK` yazmalı.

## 4. Telegram botu
1. Telegram'da **@BotFather** → `/newbot` → ad ve kullanıcı adı verin → size bir **token** verir.
2. Token'ı **sohbete yazmayın**; yalnızca `.env` dosyasında `TELEGRAM_BOT_TOKEN=` satırına yapıştırın.
3. Botunuza Telegram'dan "merhaba" yazın, sonra: `python get_chat_id.py` → çıkan sayıyı `TELEGRAM_CHAT_ID=` satırına yazın.
4. Deneme: `python main.py --demo` (DEMO etiketli bir bildirim gelir; `data/demo.db` ayrı bir veritabanıdır, gerçek kayıtlarınızı kirletmez).

## 5. Claude API (isteğe bağlı)
`.env` içine `ANTHROPIC_API_KEY=` yazın (console.anthropic.com). Boş bırakırsanız sistem **ücretsiz** kural tabanlı çalışır. Maliyet kontrolü: yalnızca yeni/değişen ve ön filtreyi geçen ilanlar gönderilir, metin 12.000 karakterle sınırlıdır, tur başına en fazla `MAX_LLM_CALLS_PER_RUN` (15) çağrı yapılır. Güncel fiyatı Anthropic fiyat sayfasından kontrol edin. Modele **kişisel profiliniz gönderilmez**, yalnızca ilan metni gider. LLM yalnızca veri çıkarır; kod/tarih/puan/yaş değerleri ilan metninde birebir yoksa reddedilir; puan ve uygunluk her zaman deterministik kurallarla hesaplanır.

## 6. Kaynakları açma (en önemli adım)
1. Bir siteyi inceleyin: `python main.py --probe https://www.tcddtasimacilik.gov.tr/` → robots.txt izni ve RSS bağlantıları listelenir.
2. İzin varsa `sources.json` içinde ilgili kaynağın `enabled` değerini `true` yapın; RSS varsa `feeds` bölümünü, yoksa `html_lists` bölümünü ve **tarayıcıda siteyi inceleyerek** CSS seçicilerini ayarlayın.
3. `python main.py --check-sources` → her kaynak için `OK/HATA` raporu. Erişilemeyen kaynak asla uydurma veriyle doldurulmaz; art arda 3 başarısızlıkta Telegram'dan uyarı gelir.
4. ÖSYM kılavuz PDF'i yayımlandığında `QUAL_CODES_VERIFIED=true` yapmadan önce, kodlarınızı PDF'teki "nitelik kodları" tablosundan **elle** doğrulayın.

## 7. Çalıştırma — bilgisayarınız kapalıyken de
- **Basit (PC açıkken):** Windows *Görev Zamanlayıcı* → Temel görev → her gün, 6 saatte bir tekrar → Program: `C:\ai_job_hunter\.venv\Scripts\python.exe`, Bağımsız değişken: `main.py --once`, Başlangıç: `C:\ai_job_hunter`.
- **Gerçekten 7/24:** küçük bir Linux sunucu (ör. aylık birkaç dolarlık VPS veya ücretsiz bulut katmanları; güncel ücretleri kendiniz kontrol edin). Aynı klasörü kurun ve `crontab -e` içine: `0 */6 * * * cd /opt/ai_job_hunter && .venv/bin/python main.py --once` ve `0 9 * * 1 cd /opt/ai_job_hunter && .venv/bin/python main.py --weekly`.
- **6 saatlik sıklık** kaynak sınırları için makuldür: her kaynağa tur başına birkaç istek, alan adı başına ≥3 sn aralık, robots.txt'ye uyum. Daha sık çalıştırmayın.
- **n8n (isteğe bağlı):** `workflow.json` dosyasını n8n → *Import from file* ile alın. Python kendi bildirimini gönderir; n8n **zamanlayıcı + hata uyarıcısı** görevi görür. Düğümlerde klasör yolu `C:\ai_job_hunter` varsayılmıştır, gerekirse düzeltin; "Telegram" düğümüne kendi kimlik bilginizi seçin ve `BURAYA_CHAT_ID` yerine chat ID'nizi yazın. Not: *Execute Command* düğümü yeni n8n sürümlerinde (ve n8n Cloud'da) varsayılan olarak devre dışı olabilir; bu durumda Görev Zamanlayıcı/cron kullanın. n8n sürümünüz için içe aktarma sonrası düğümleri kontrol edin.
- **Yedekleme:** her turdan sonra `backups/` altına otomatik yedek (son 14).
- **Panel:** `pip install streamlit pandas` (gerekirse) sonra `streamlit run panel.py`.

## 7b. Bildirim kuralları
Yeni uygun ilan (≥ `NOTIFY_MIN_SCORE`, durum "karşılıyor/muhtemelen") → bildirim; ≥90 → 🚨 öncelikli. Aynı ilan tekrar gönderilmez (URL değişse bile). Son başvuruya 3 gün ve 1 gün kala hatırlatma. İlan güncellenir ya da iptal edilirse haber verilir. Kapanmış ilan "yeni ilan" olarak gönderilmez. Panelde "İlgilenmiyorum / Başvurdum" işaretlediğiniz ilanlar için bildirim gitmez.

## 8. Sorun giderme
`logs/jobhunter.log` dosyasına bakın (token ve şifreler maskelenir). "Başka bir çalışma sürüyor" mesajı normaldir; 3 saatten eski kilit otomatik silinir.
