"""Ortak HTTP katmanı (robots.txt, hız sınırı, yeniden deneme, timeout) ve kaynak taban sınıfı."""
from __future__ import annotations

import io
import logging
import time
import urllib.robotparser
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

log = logging.getLogger(__name__)
USER_AGENT = "KisiselIsIlaniTakipBotu/1.0 (kisisel kullanim; dusuk hacim)"
MIN_INTERVAL = 3.0   # aynı alan adına en az 3 saniyede bir istek
TIMEOUT = (10, 30)   # (bağlanma, okuma) saniye
MAX_BYTES = 8_000_000


def make_soup(content):
    """lxml kuruluysa onu, değilse standart html.parser'ı kullanır (Termux'ta lxml derlemek zor olabilir)."""
    try:
        return BeautifulSoup(content, "lxml")
    except Exception:
        return BeautifulSoup(content, "html.parser")


class SourceError(Exception):
    """Kaynağa erişilemedi / izin yok / beklenmeyen yapı. Veri uydurulmaz; hata raporlanır."""


@dataclass
class RawAd:
    source: str
    title: str
    url: str
    source_id: Optional[str] = None
    institution: str = ""
    city: str = ""
    category: str = "kamu"          # kamu | ozel
    text: str = ""                  # ilan metni (boşsa detay sayfasından çekilir)
    deadline: Optional[str] = None  # YYYY-MM-DD (yalnızca kaynak açıkça veriyorsa)
    extra: dict = field(default_factory=dict)


class Http:
    def __init__(self):
        self.s = requests.Session()
        self.s.headers["User-Agent"] = USER_AGENT
        retry = Retry(total=3, backoff_factor=2, status_forcelist=(429, 500, 502, 503, 504),
                      allowed_methods=("GET", "POST"), respect_retry_after_header=True)
        self.s.mount("https://", HTTPAdapter(max_retries=retry))
        self.s.mount("http://", HTTPAdapter(max_retries=retry))
        self._last: dict[str, float] = {}
        self._robots: dict[str, Optional[urllib.robotparser.RobotFileParser]] = {}

    def _throttle(self, host: str):
        wait = MIN_INTERVAL - (time.time() - self._last.get(host, 0))
        if wait > 0:
            time.sleep(wait)
        self._last[host] = time.time()

    def allowed(self, url: str) -> bool:
        """robots.txt kontrolü. robots.txt 404 ise serbest; alınamıyorsa güvenli tarafta kalıp izin VERMEZ."""
        u = urlparse(url)
        base = f"{u.scheme}://{u.netloc}"
        if base not in self._robots:
            rp = urllib.robotparser.RobotFileParser()
            try:
                self._throttle(u.netloc)
                r = self.s.get(base + "/robots.txt", timeout=TIMEOUT)
                if r.status_code == 404:
                    rp.parse([])
                elif r.status_code == 200:
                    rp.parse(r.text.splitlines())
                else:
                    rp = None
            except requests.RequestException:
                rp = None
            self._robots[base] = rp
        rp = self._robots[base]
        return bool(rp and rp.can_fetch(USER_AGENT, url))

    def request(self, method: str, url: str, max_bytes: int = MAX_BYTES, **kw) -> requests.Response:
        if not self.allowed(url):
            raise SourceError(f"robots.txt izin vermiyor veya okunamadı: {url}")
        self._throttle(urlparse(url).netloc)
        try:
            r = self.s.request(method, url, timeout=TIMEOUT, stream=True, **kw)
            body = r.raw.read(max_bytes + 1, decode_content=True)
            if len(body) > max_bytes:
                raise SourceError("Yanıt çok büyük")
            r._content = body
        except requests.RequestException as e:
            raise SourceError(f"HTTP hatası ({type(e).__name__}): {url}") from e
        if r.status_code in (401, 403, 429) or "captcha" in r.text[:5000].lower():
            raise SourceError(f"Erişim engeli/oturum/CAPTCHA ({r.status_code}); aşılmaya çalışılmaz: {url}")
        if r.status_code >= 400:
            raise SourceError(f"HTTP {r.status_code}: {url}")
        return r

    def get(self, url: str, **kw):
        return self.request("GET", url, **kw)

    def page_text(self, url: str) -> str:
        """HTML veya PDF'den düz metin çıkarır."""
        r = self.get(url)
        ctype = r.headers.get("content-type", "").lower()
        if "pdf" in ctype or url.lower().split("?")[0].endswith(".pdf"):
            try:
                from pypdf import PdfReader
                rd = PdfReader(io.BytesIO(r.content))
                return "\n".join((p.extract_text() or "") for p in rd.pages[:40])
            except Exception as e:
                raise SourceError(f"PDF okunamadı ({type(e).__name__}): {url}") from e
        soup = make_soup(r.content)
        for t in soup(["script", "style", "noscript", "nav", "footer"]):
            t.decompose()
        return soup.get_text("\n", strip=True)


class Source:
    name = "base"
    http: Http

    def __init__(self, http: Optional[Http] = None):
        self.http = http or Http()

    def fetch(self) -> list[RawAd]:
        raise NotImplementedError
