"""ilan.gov.tr — DENEYSEL / DOĞRULANMAMIŞ.

ilan.gov.tr'nin resmî, belgelenmiş bir genel API'si bulunamadı. Topluluk projelerinde sitenin kendi ön yüzünün kullandığı
bir JSON uç noktası kullanılıyor; bu uç nokta duyuru yapılmadan değişebilir ve kullanım koşulları/robots.txt kısıtları
geçerlidir. Bu yüzden varsayılan olarak KAPALIDIR (.env: ENABLE_ILAN_GOV=false).
Açmadan önce:  python main.py --probe https://www.ilan.gov.tr  ile robots.txt durumunu kontrol edin ve
sitenin kullanım koşullarını okuyun. 'keys' ve yanıt alan adları varsayımdır; yanıt beklenen yapıda değilse SourceError verir.
"""
from __future__ import annotations

from .base import RawAd, Source, SourceError

ENDPOINT = "https://www.ilan.gov.tr/api/api/services/app/Ad/AdsByFilter"
BASE = "https://www.ilan.gov.tr"


class IlanGovSource(Source):
    name = "ilan_gov_tr"

    def __init__(self, queries=None, http=None):
        super().__init__(http)
        self.queries = queries or ["tekniker"]

    def fetch(self) -> list[RawAd]:
        out, seen, errors = [], set(), []
        for q in self.queries:
            payload = {"keys": {"q": [q]}, "skipCount": 0, "maxResultCount": 30}
            try:
                r = self.http.request("POST", ENDPOINT, json=payload)
                data = r.json()
                items = (data.get("result") or {}).get("ads") or (data.get("result") or {}).get("items") or []
            except SourceError as e:
                errors.append(str(e))
                continue
            except Exception as e:
                errors.append(f"yanıt JSON değil ({q})")
                continue
            for ad in items:
                url = ad.get("urlStr")
                sid = str(ad.get("id") or url)
                if not url or not ad.get("title") or sid in seen:
                    continue
                seen.add(sid)
                out.append(RawAd(source=self.name, title=ad["title"], url=BASE + url, source_id=sid,
                                 institution=ad.get("adSourceName") or "", city=ad.get("addressCityName") or ""))
        if not out:
            raise SourceError("ilan.gov.tr: sonuç yok (" + ("; ".join(errors[:2]) or "uç nokta/anahtar yapısı değişmiş olabilir") + ")")
        return out
