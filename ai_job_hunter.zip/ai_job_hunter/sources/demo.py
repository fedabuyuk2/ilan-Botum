"""DEMO kaynağı: tests/sample_ads.json içindeki UYDURMA örnek ilanları okur. Yalnızca `--demo` ile ve ayrı veritabanında çalışır."""
from __future__ import annotations

import json
from pathlib import Path
from .base import RawAd, Source

SAMPLE = Path(__file__).resolve().parent.parent / "tests" / "sample_ads.json"


class DemoSource(Source):
    name = "demo"

    def __init__(self, http=None):
        self.http = http

    def fetch(self) -> list[RawAd]:
        data = json.loads(SAMPLE.read_text(encoding="utf-8"))
        return [RawAd(source="demo", title=d["title"], url=d["url"], source_id=d["id"], institution=d["institution"],
                      city=d.get("city", ""), category=d.get("category", "kamu"), text=d["text"]) for d in data]
