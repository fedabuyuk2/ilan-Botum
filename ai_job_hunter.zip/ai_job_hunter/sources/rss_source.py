"""Genel RSS/Atom kaynağı. sources.json içindeki 'feeds' listesinden beslenir."""
from __future__ import annotations

import xml.etree.ElementTree as ET
from .base import RawAd, Source, SourceError


def _t(el, *names):
    for n in names:
        x = el.find(n)
        if x is not None and (x.text or "").strip():
            return x.text.strip()
    return ""


class RssSource(Source):
    def __init__(self, cfg: dict, http=None):
        super().__init__(http)
        self.cfg = cfg
        self.name = cfg["name"]

    def fetch(self) -> list[RawAd]:
        r = self.http.get(self.cfg["url"])
        try:
            root = ET.fromstring(r.content)
        except ET.ParseError as e:
            raise SourceError(f"RSS ayrıştırılamadı: {self.cfg['url']}") from e
        ns = "{http://www.w3.org/2005/Atom}"
        items = root.findall(".//item") or root.findall(f".//{ns}entry")
        out = []
        for it in items:
            title = _t(it, "title", f"{ns}title")
            link = _t(it, "link", f"{ns}id")
            if not link:
                le = it.find(f"{ns}link")
                link = le.get("href", "") if le is not None else ""
            guid = _t(it, "guid", f"{ns}id") or link
            desc = _t(it, "description", f"{ns}summary", f"{ns}content")
            if title and link:
                out.append(RawAd(source=self.name, title=title, url=link, source_id=guid,
                                 institution=self.cfg.get("institution", ""), category=self.cfg.get("category", "kamu"), text=desc))
        return out
