"""Ayarlanabilir HTML liste ayrıştırıcı (CSS seçici ile). Seçiciler siteye göre sources.json'da doğrulanmalıdır."""
from __future__ import annotations

from urllib.parse import urljoin
from analyzer import fold
from .base import RawAd, Source, SourceError, make_soup


class HtmlListSource(Source):
    def __init__(self, cfg: dict, http=None):
        super().__init__(http)
        self.cfg = cfg
        self.name = cfg["name"]

    def fetch(self) -> list[RawAd]:
        r = self.http.get(self.cfg["list_url"])
        soup = make_soup(r.content)
        kws = [fold(k) for k in self.cfg.get("include_keywords", [])]
        out, seen = [], set()
        for a in soup.select(self.cfg.get("item_selector", "a")):
            href = a.get(self.cfg.get("href_attr", "href"))
            title = a.get_text(" ", strip=True) if self.cfg.get("title_attr", "text") == "text" else a.get(self.cfg["title_attr"], "")
            if not href or not title or len(title) < 12:
                continue
            if kws and not any(k in fold(title) for k in kws):
                continue
            url = urljoin(self.cfg["list_url"], href)
            if url in seen:
                continue
            seen.add(url)
            out.append(RawAd(source=self.name, title=title[:300], url=url, source_id=url,
                             institution=self.cfg.get("institution", ""), category=self.cfg.get("category", "kamu")))
        if not out:
            raise SourceError(f"{self.name}: liste boş döndü (seçiciler yanlış olabilir veya sayfa yapısı değişti)")
        return out
