"""sources.json'dan etkin kaynakları kurar."""
from __future__ import annotations

import json
from pathlib import Path

import config
from .base import Http
from .html_list import HtmlListSource
from .ilan_gov import IlanGovSource
from .rss_source import RssSource


def build_sources(http=None, path: Path = config.BASE_DIR / "sources.json"):
    http = http or Http()
    cfg = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    out = []
    for f in cfg.get("feeds", []):
        if f.get("enabled"):
            out.append(RssSource(f, http))
    for h in cfg.get("html_lists", []):
        if h.get("enabled"):
            out.append(HtmlListSource(h, http))
    if config.ENABLE_ILAN_GOV:
        out.append(IlanGovSource(queries=cfg.get("ilan_gov_queries"), http=http))
    return out
