"""ÖSYM KPSS tercih kılavuzu tablolarını okur (Tablo-2 ön lisans kadroları + nitelik kodu tablosu).

DİKKAT: Ayrıştırıcılar resmî PDF'lerden alınan örnek satır biçimlerine göre yazıldı, ancak gerçek PDF dosyalarının tamamıyla
denenmedi (geliştirme ortamında internet yoktu). Sonuç satırlarının sayısı Telegram özetinde gösterilir; beklenenden azsa bildirin.
"""
from __future__ import annotations

import io
import logging
import re
from typing import Optional

from analyzer import fold

log = logging.getLogger(__name__)

# Resmî ÖSYM nitelik tablolarında (KPSS-2025/2 ve 2026/1 ön lisans tabloları) görülen ve elle doğrulanan kodlar.
VERIFIED_CODES = {
    "3001": "Herhangi bir önlisans programından mezun olmak.",
    "3205": "Demiryolu Araçları, Raylı Sistemler Teknolojisi veya Raylı Sistemler Makine Teknolojisi önlisans programlarının birinden mezun olmak.",
    "3206": "Raylı Sistemler Elektrik-Elektronik Teknolojisi veya Raylı Sistemler Elektrik ve Elektronik Teknolojisi önlisans programından mezun olmak.",
    "3207": "Demiryolu İnşaatı ve İşletmeciliği, Raylı Sistemler, Raylı Sistemler Yol, Raylı Sistemler Yol Teknolojisi önlisans programlarının birinden mezun olmak.",
    "3208": "Raylı Sistemler Makinistlik veya Raylı Sistemler Makinistliği önlisans programından mezun olmak.",
    "3290": "Elektrik veya Elektrik Teknolojisi önlisans programından mezun olmak.",
}
ILLER = ["ADANA", "ADIYAMAN", "AFYONKARAHİSAR", "AĞRI", "AKSARAY", "AMASYA", "ANKARA", "ANTALYA", "ARDAHAN", "ARTVİN", "AYDIN", "BALIKESİR",
         "BARTIN", "BATMAN", "BAYBURT", "BİLECİK", "BİNGÖL", "BİTLİS", "BOLU", "BURDUR", "BURSA", "ÇANAKKALE", "ÇANKIRI", "ÇORUM", "DENİZLİ",
         "DİYARBAKIR", "DÜZCE", "EDİRNE", "ELAZIĞ", "ERZİNCAN", "ERZURUM", "ESKİŞEHİR", "GAZİANTEP", "GİRESUN", "GÜMÜŞHANE", "HAKKARİ", "HATAY",
         "IĞDIR", "ISPARTA", "İSTANBUL", "İZMİR", "KAHRAMANMARAŞ", "KARABÜK", "KARAMAN", "KARS", "KASTAMONU", "KAYSERİ", "KIRIKKALE",
         "KIRKLARELİ", "KIRŞEHİR", "KİLİS", "KOCAELİ", "KONYA", "KÜTAHYA", "MALATYA", "MANİSA", "MARDİN", "MERSİN", "MUĞLA", "MUŞ", "NEVŞEHİR",
         "NİĞDE", "ORDU", "OSMANİYE", "RİZE", "SAKARYA", "SAMSUN", "SİİRT", "SİNOP", "SİVAS", "ŞANLIURFA", "ŞIRNAK", "TEKİRDAĞ", "TOKAT",
         "TRABZON", "TUNCELİ", "UŞAK", "VAN", "YALOVA", "YOZGAT", "ZONGULDAK"]
_IL_RE = re.compile(r"(?<![A-ZÇĞİÖŞÜ])(" + "|".join(sorted(ILLER, key=len, reverse=True)) + r")(?![A-ZÇĞİÖŞÜ])")
_EMP_RE = re.compile(r"(?<![A-ZÇĞİÖŞÜ])(KİT SÖZLEŞMELİ PERSONEL|SÖZLEŞMELİ PERSONEL|MEMUR)(?![A-ZÇĞİÖŞÜ])")
_ROW_START = re.compile(r"(?<!\d)(20\d{7})(?!\d)")


def pdf_text(data: bytes, max_pages: int = 1500) -> str:
    from pypdf import PdfReader
    rd = PdfReader(io.BytesIO(data))
    return "\n".join((p.extract_text() or "") for p in rd.pages[:max_pages])


# ----------------------------------------------------------------------------- Tablo-2 (kadro satırları)
def parse_tablo(text: str) -> list[dict]:
    t = re.sub(r"Aranan Nitelikleri mutlaka okuyunuz\.?", " ", text or "")
    t = t.replace("·", " | ")
    t = re.sub(r"\s+", " ", t)
    starts = list(_ROW_START.finditer(t))
    rows = []
    for i, m in enumerate(starts):
        chunk = t[m.end(): starts[i + 1].start() if i + 1 < len(starts) else len(t)]
        r = _parse_chunk(m.group(1), chunk)
        if r:
            rows.append(r)
    return rows


def _parse_chunk(code: str, chunk: str) -> Optional[dict]:
    em = _EMP_RE.search(chunk)
    if not em:
        return None
    institution = re.sub(r"^[\s|]*\d{3,7}[\s|]*", "", chunk[: em.start()]).strip(" |")
    rest = chunk[em.end():]
    tm = re.search(r"(\d{1,4})[\s|]+((?:\d{4}[\s|]*){1,14})\s*$", rest)
    if not tm:
        return None
    codes = re.findall(r"\d{4}", tm.group(2))
    mid = rest[: tm.start()].strip(" |")
    im = _IL_RE.search(mid)
    return {"osym_code": code, "institution": institution, "employment": em.group(1),
            "title": (mid[: im.start()] if im else mid).strip(" |"), "city": im.group(1) if im else "",
            "place": (mid[im.end():] if im else "").strip(" |")[:80], "quota": int(tm.group(1)), "codes": codes}


# ----------------------------------------------------------------------------- nitelik kodu tablosu (kod -> açıklama, mezuniyet alan kodları)
def parse_nitelik(text: str) -> dict[str, dict]:
    t = re.sub(r"\s+", " ", (text or "").replace("·", " ").replace("|", " "))
    out: dict[str, dict] = {}
    for m in re.finditer(r"(?<!\d)(3\d{3})\s+([A-ZÇĞİÖŞÜ][^.]{5,400}?mezun olmak\.)((?:\s*\d{4}(?!\d)(?!\s+[^\W\d_]))*)", t):
        areas = re.findall(r"\d{4}", m.group(3))
        out.setdefault(m.group(1), {"text": m.group(2).strip(), "areas": areas})
    return out


def codes_for_area(table: dict[str, dict], area: str) -> list[str]:
    return sorted(c for c, v in table.items() if area in v["areas"])


# ----------------------------------------------------------------------------- eşleştirme
def match_row(row: dict, my_codes: set[str]) -> dict:
    """Aynı kadroda birden fazla program/alan kodu varsa birinin karşılanması yeterlidir (ÖSYM kılavuz 3.3);
    diğer kodlar (cinsiyet, sertifika, özel şart) ayrıca sağlanmalıdır ve burada YORUMLANMAZ."""
    edu = [c for c in row["codes"] if c[0] == "3"]
    others = [c for c in row["codes"] if c[0] != "3"]
    return {"edu_ok": bool(edu) and any(c in my_codes for c in edu), "edu_codes": edu, "other_codes": others,
            "generic": "3001" in edu}


def priority(row: dict) -> int:
    f = fold(f"{row['institution']} {row['title']}")
    if "demiryollari" in f or "tcdd" in f:
        return 0
    if any(k in f for k in ("rayli", "tekniker", "teknik")):
        return 1
    return 2


# ----------------------------------------------------------------------------- veritabanı + özet
def store_rows(db, guide: str, rows: list[dict], my_codes: set[str]) -> int:
    with db.tx() as c:
        c.execute("DELETE FROM guide_rows WHERE guide=?", (guide,))
        for r in rows:
            m = match_row(r, my_codes)
            c.execute("INSERT OR REPLACE INTO guide_rows (guide,osym_code,institution,employment,title,city,place,quota,codes,edu_ok,generic,prio) "
                      "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (guide, r["osym_code"], r["institution"], r["employment"], r["title"], r["city"], r["place"], r["quota"],
                       " ".join(r["codes"]), int(m["edu_ok"]), int(m["generic"]), priority(r)))
    return len(rows)


def query_matches(db, guide: Optional[str] = None, limit: int = 12, only_prio: Optional[int] = None) -> list:
    sql = "SELECT * FROM guide_rows WHERE edu_ok=1" + (" AND guide=?" if guide else "")
    args = [guide] if guide else []
    if only_prio is not None:
        sql += " AND prio=?"
        args.append(only_prio)
    return db.conn.execute(sql + " ORDER BY prio ASC, generic ASC, quota DESC LIMIT ?", (*args, limit)).fetchall()


def format_rows(rows) -> str:
    import html
    e = lambda x: html.escape(str(x or "—"))
    out = []
    for r in rows:
        cs = r["codes"].split()
        extra = [c for c in cs if c[0] != "3"]
        out.append(f"• <b>{e(r['institution'])}</b>\n  {e(r['title'])} ({e(r['employment'])}) — {e(r['city'])} {e(r['place'])}, kontenjan {r['quota']}\n"
                   f"  Kodlar: {' '.join(cs)}" + (f"  ⚠ Ek şart kodları ({' '.join(extra)}) kılavuzdan okunmalı" if extra else "") + f"\n  ÖSYM kodu: {r['osym_code']}")
    return "\n".join(out)


def summary(db, guide: str, my_codes: set[str]) -> str:
    total = db.conn.execute("SELECT COUNT(*) FROM guide_rows WHERE guide=?", (guide,)).fetchone()[0]
    ok = db.conn.execute("SELECT COUNT(*) FROM guide_rows WHERE guide=? AND edu_ok=1", (guide,)).fetchone()[0]
    gen = db.conn.execute("SELECT COUNT(*) FROM guide_rows WHERE guide=? AND edu_ok=1 AND generic=1", (guide,)).fetchone()[0]
    tcdd = db.conn.execute("SELECT COUNT(*) FROM guide_rows WHERE guide=? AND edu_ok=1 AND prio=0", (guide,)).fetchone()[0]
    head = (f"📘 <b>{guide} kılavuzu işlendi</b>\nOkunan kadro: {total}\nKodlarınıza ({', '.join(sorted(my_codes))}) uyan: {ok} "
            f"(bunların {gen} tanesi genel 3001)\nTCDD/Demiryolu: {tcdd}\n")
    if total == 0:
        head += "\n⚠️ Hiç satır okunamadı; PDF biçimi beklenenden farklı olabilir. Dosyayı bana bildirin."
    elif total < 50:
        head += "\n⚠️ Beklenenden az satır okundu; ayrıştırıcıyı birlikte düzeltelim."
    top = query_matches(db, guide, limit=8)
    return head + ("\n" + format_rows(top) if top else "") + "\n\n/kilavuz komutuyla listeyi görebilirsiniz. Ek şart kodlarını (1xxx, 6xxx, 7xxx) kılavuzdan okuyun."


def ingest(db, guide: str, tablo_text: str, nitelik_text: Optional[str], my_codes: set[str]) -> str:
    rows = parse_tablo(tablo_text)
    store_rows(db, guide, rows, my_codes)
    if nitelik_text:
        tbl = parse_nitelik(nitelik_text)
        db.set_setting("nitelik_table_size", len(tbl))
    return summary(db, guide, my_codes)


# ----------------------------------------------------------------------------- yeni kılavuz izleme
WATCH_PAGES = {
    "KPSS-2026/2": "https://www.osym.gov.tr/kpss20262-bazi-kamu-kurum-ve-kuruluslarinin-kadro-ve-pozisyonlarina-yerlestirme-yapmak-icin-tercih-kilavuzu-ve-tablolar",
}


def check_new_guides(db, http, my_codes: set[str], send) -> int:
    """Bilinen ÖSYM sayfa adresi açılırsa PDF bağlantılarını bulur, Tablo-2'yi indirir, işler ve özet gönderir.
    Sayfa henüz yoksa (404) sessizce geçer. Adresler tahmindir: ÖSYM farklı bir adres kullanırsa yakalanamaz (README'ye bakın)."""
    from sources.base import SourceError, make_soup
    from urllib.parse import urljoin
    done = 0
    for guide, page in WATCH_PAGES.items():
        if db.get_setting(f"guide_done:{guide}"):
            continue
        try:
            r = http.get(page)
        except SourceError as ex:
            log.info("Kılavuz sayfası henüz yok/erişilemedi (%s): %s", guide, str(ex)[:80])
            continue
        links = [urljoin(page, a["href"]) for a in make_soup(r.content).select("a[href]") if a["href"].lower().split("?")[0].endswith(".pdf")]
        tablo = next((u for u in links if "tablo2" in u.lower() or "onlisans" in u.lower() and "tablo" in u.lower()), None)
        nitelik = next((u for u in links if "nitelik" in u.lower() and ("onlisans" in u.lower() or "on-lisans" in u.lower())), None)
        if not tablo:
            send(f"ℹ️ {guide} sayfası açıldı ama Tablo-2 PDF bağlantısı bulunamadı: {page}")
            db.set_setting(f"guide_done:{guide}", "sayfa-var-pdf-yok")
            continue
        try:
            tt = pdf_text(http.request("GET", tablo, max_bytes=60_000_000).content)
            nt = pdf_text(http.request("GET", nitelik, max_bytes=60_000_000).content) if nitelik else None
        except Exception as ex:
            send(f"⚠️ {guide} PDF'leri okunamadı ({type(ex).__name__}). PDF'leri depodaki kilavuz/ klasörüne yükleyip workflow'u 'guide_files' ile çalıştırın.")
            continue
        send(ingest(db, guide, tt, nt, my_codes))
        db.set_setting(f"guide_done:{guide}", "tamam")
        done += 1
    return done


def process_files(db, directory: str, my_codes: set[str], send) -> int:
    """Depodaki kilavuz/ klasöründeki PDF'leri işler. Dosya adlarında 'tablo2' (kadro tablosu) ve 'nitelik' geçmeli.
    Kılavuz adı için dosya adına KPSS-2026-2 gibi bir ifade koyun (ör. tablo2_KPSS-2026-2.pdf)."""
    import glob, os
    files = sorted(glob.glob(os.path.join(directory, "*.pdf")))
    tabs = [f for f in files if "tablo2" in os.path.basename(f).lower()]
    nits = [f for f in files if "nitelik" in os.path.basename(f).lower()]
    if not tabs:
        send("ℹ️ kilavuz/ klasöründe 'tablo2' adlı PDF bulunamadı.")
        return 0
    n = 0
    for tf in tabs:
        m = re.search(r"(KPSS)[-_ ]?(\d{4})[-_/ ](\d)", os.path.basename(tf), re.I)
        guide = f"KPSS-{m.group(2)}/{m.group(3)}" if m else os.path.basename(tf)
        with open(tf, "rb") as fh:
            tt = pdf_text(fh.read())
        nt = None
        if nits:
            with open(nits[0], "rb") as fh:
                nt = pdf_text(fh.read())
        send(ingest(db, guide, tt, nt, my_codes))
        n += 1
    return n
