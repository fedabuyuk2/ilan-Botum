"""Bağımlılıksız mobil uyumlu panel (yalnızca Python standart kütüphanesi). Çalıştırma:  python panel_lite.py
Sonra telefonun tarayıcısında http://127.0.0.1:8501 adresini açın. Yalnızca bu cihazdan erişilir."""
import html
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

import config

HOST, PORT = "127.0.0.1", 8501
ST = {"takip": "Takip et", "basvuracagim": "Başvuracağım", "basvurdum": "Başvurdum",
      "sonuc_bekliyorum": "Sonuç bekliyorum", "ilgilenmiyorum": "İlgilenmiyorum"}
ELIG = "status IN ('Şartları karşılıyor','Muhtemelen karşılıyor')"
VIEWS = {
    "tumu": ("Tümü", "1=1", "score DESC"),
    "yeni": ("Yeni (3 gün)", "first_seen >= datetime('now','-3 day','localtime')", "first_seen DESC"),
    "en": ("En yüksek puan", f"lifecycle='active' AND {ELIG}", "score DESC"),
    "yaklasan": ("Süresi yaklaşan", f"lifecycle='active' AND deadline BETWEEN date('now','localtime') AND date('now','+7 day','localtime')", "deadline ASC"),
    "guvenlik": ("Askeri/Polis/Zabıta", "lifecycle='active' AND tags LIKE '%guvenlik%'", "score DESC"),
    "genel": ("3001 genel önlisans", "lifecycle='active' AND tags LIKE '%genel3001%'", "score DESC"),
    "tcdd": ("TCDD", "(institution LIKE '%TCDD%' OR institution LIKE '%Demiryol%')", "score DESC"),
    "kamu": ("Diğer kamu", "category='kamu' AND institution NOT LIKE '%TCDD%' AND institution NOT LIKE '%Demiryol%'", "score DESC"),
    "ozel": ("Özel sektör", "category='ozel'", "score DESC"),
    "kontrol": ("Kontrol edilmeli", "status='Ek doğrulama gerekli'", "score DESC"),
    "takipte": ("Kaydedilen/Başvurulan", "user_status IN ('takip','basvuracagim','basvurdum','sonuc_bekliyorum')", "score DESC"),
    "kapanan": ("Kapanan/Uygun değil", "lifecycle!='active' OR status='Şartları karşılamıyor'", "score DESC"),
}
CSS = ("body{font-family:sans-serif;margin:0;padding:10px;background:#f4f5f7;color:#222}h1{font-size:1.2em}"
       ".c{background:#fff;border-radius:10px;padding:10px;margin:8px 0;box-shadow:0 1px 3px #0002}"
       ".s{font-weight:bold;font-size:1.3em}.w{color:#a05a00;font-size:.9em}select,input,button{font-size:1em;padding:6px;margin:2px 0}"
       "a{color:#0a58ca}")


def page(view, q):
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    name, where, order = VIEWS.get(view, VIEWS["tumu"])
    sql, args = f"SELECT * FROM ads WHERE {where}", []
    if q:
        sql += " AND (institution LIKE ? OR title LIKE ? OR city LIKE ?)"
        args = [f"%{q}%"] * 3
    rows = conn.execute(sql + f" ORDER BY {order} LIMIT 100", args).fetchall()
    e = lambda x: html.escape(str(x if x not in (None, "") else "—"))
    opts = "".join(f'<option value="{k}"{" selected" if k == view else ""}>{v[0]}</option>' for k, v in VIEWS.items())
    out = [f"<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><style>{CSS}</style>",
           "<h1>🚆 İş İlanı Takip</h1>",
           f"<form><select name=view>{opts}</select> <input name=q placeholder=Ara value='{html.escape(q or '')}'> <button>Göster</button></form>",
           f"<p>{len(rows)} ilan</p>"]
    for r in rows:
        reasons = json.loads(r["reasons"] or "[]")
        warns = json.loads(r["warnings"] or "[]")
        so = '<option value="">—</option>' + "".join(f'<option value="{k}"{" selected" if k == r["user_status"] else ""}>{v}</option>' for k, v in ST.items())
        url = r["url"] or ""
        link = f'<a href="{html.escape(url)}" rel="noreferrer">Resmî ilan</a>' if url.startswith(("http://", "https://")) else ""
        out.append(f"<div class=c><span class=s>{e(r['score'])}/100</span> {e(r['institution'])} — <b>{e(r['title'])}</b> ({e(r['city'])})<br>"
                   f"{e(r['status'])} • {e(r['lifecycle'])} • Son başvuru: {e(r['deadline'] or 'doğrulanamadı')}<br>"
                   + "".join(f"• {e(x)}<br>" for x in reasons[:4]) + "".join(f"<span class=w>⚠ {e(x)}</span><br>" for x in warns[:4])
                   + f"{link}<form method=post action=/status><input type=hidden name=id value={int(r['id'])}>"
                     f"<input type=hidden name=view value='{html.escape(view)}'><select name=st>{so}</select> <button>Kaydet</button></form></div>")
    conn.close()
    return "".join(out).encode("utf-8")


class H(BaseHTTPRequestHandler):
    def _local(self):
        return self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self._local():
            return self.send_error(403)
        qs = parse_qs(urlparse(self.path).query)
        body = page(qs.get("view", ["tumu"])[0], qs.get("q", [""])[0])
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self._local() or urlparse(self.path).path != "/status":
            return self.send_error(403)
        d = parse_qs(self.rfile.read(int(self.headers.get("Content-Length", 0))).decode())
        st = d.get("st", [""])[0]
        if st in ST or st == "":
            conn = sqlite3.connect(config.DB_PATH)
            conn.execute("UPDATE ads SET user_status=? WHERE id=?", (st or None, int(d["id"][0])))
            conn.commit()
            conn.close()
        self.send_response(303)
        self.send_header("Location", "/?view=" + d.get("view", ["tumu"])[0])
        self.end_headers()

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    print(f"Panel: http://{HOST}:{PORT}  (durdurmak için CTRL+C)")
    HTTPServer((HOST, PORT), H).serve_forever()
