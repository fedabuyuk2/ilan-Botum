# 📱 Xiaomi Redmi 10 (2022) — MIUI 14 / Android 14 Kurulum Rehberi (Termux)

Telefon, sistemi **Termux** (Android'de Linux terminali) ile çalıştırır. Bilgisayar gerekmez, telefon açık ve internete bağlı olduğu sürece çalışır. Ek maliyet yoktur (Claude API isteğe bağlıdır).

> Dürüst not: Bu rehberi Redmi 10'da fiilen deneyemedim; adımlar Termux/MIUI'nin bilinen davranışlarına dayanır. MIUI arayüz menü adları sürüme göre biraz değişebilir.

## A. Uygulamaları kurun (Play Store'dan DEĞİL!)
Play Store'daki Termux eskidir ve çalışmaz. Hepsini **aynı kaynaktan** kurun (karışık kaynak "imza uyuşmazlığı" hatası verir):
1. Telefon tarayıcısından **f-droid.org** → F-Droid'i indirip kurun (MIUI "bilinmeyen kaynaktan yüklemeye izin ver" sorarsa tarayıcı için izin verin).
2. F-Droid içinde arayıp kurun: **Termux**, **Termux:Boot**, **Termux:API**.
3. Üçünü de bir kez açın (Termux:Boot ve Termux:API'de boş ekran normaldir). Bildirim izni isterlerse **İzin ver**.

## B. MIUI ayarları (en kritik adım — yoksa MIUI arka planda uygulamayı öldürür)
**Ayarlar → Uygulamalar → Uygulamaları yönet →** *Termux*, *Termux:Boot* ve *Termux:API* için ayrı ayrı:
- **Otomatik başlat (Autostart): AÇIK**
- **Pil tasarrufu (Battery saver) → "Kısıtlama yok" (No restrictions)**
- **Diğer izinler → "Arka planda açılır pencere göster" AÇIK** (görünürse)
- **Bildirimler: izin ver**
Ardından **Son uygulamalar** ekranını açın, Termux kartına uzun basın → **kilit simgesi** (uygulamayı kilitle).
Ayrıca **Ayarlar → Pil → Pil tasarrufu** kapalı olsun.

## C. Proje dosyalarını telefona alın
1. Claude'dan indirdiğiniz **ai_job_hunter.zip** dosyası "İndirilenler (Downloads)" klasöründe olmalı.
2. Termux'u açın ve sırayla yazın (her satırdan sonra Enter):
```
termux-setup-storage
```
(İzin penceresinde **İzin ver**.)
```
pkg update -y && pkg upgrade -y
pkg install -y python unzip nano termux-api
cd ~
cp ~/storage/downloads/ai_job_hunter.zip .
unzip -o ai_job_hunter.zip
cd ai_job_hunter
pip install -r requirements.txt
```
Güncelleme sırasında "Y/N" (config dosyası) sorarsa **Enter** (varsayılan) yeterlidir. `pip install --upgrade pip` YAPMAYIN.

## D. Yapılandırma (.env)
```
cp .env.example .env
nano .env
```
`nano` kullanımı: yazın; kaydetmek için Termux'un üstündeki ekstra tuş satırından **CTRL** basılı yapıp **O**, Enter; çıkmak için **CTRL + X**.
Doldurun: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` (aşağıda), isteğe bağlı `ANTHROPIC_API_KEY`. Tokenları sohbete yazmayın.

**Telegram botu:** Telegram'da **@BotFather** → `/newbot` → token'ı `.env`'ye yazın. Botunuza "merhaba" yazın, sonra Termux'ta `python get_chat_id.py` → çıkan sayıyı `TELEGRAM_CHAT_ID=` satırına yazın.

## E. Deneme
```
python -m unittest discover -s tests
python main.py --demo --dry-run --no-llm
python main.py --demo
```
İlk komut `OK`, ikincisi ekranda örnek bildirim, üçüncüsü Telegram'a **[DEMO — UYDURMA]** etiketli mesaj göndermelidir (gelirse bildirim hattı çalışıyor demektir).

## F. Kaynakları açma
```
python main.py --probe https://www.tcddtasimacilik.gov.tr/
nano sources.json
python main.py --check-sources
```
`sources.json` içinde kaynağın `enabled` değerini `true` yapın ve CSS seçicilerini siteye bakarak ayarlayın (ayrıntı: README.md Bölüm 6). Dikkat: JSON'da virgül/tırnak hatası yapmayın. Seçici ayarında takılırsanız `--check-sources` çıktısını bana gönderin.

## G. Telegram botu olarak çalıştırma (önerilen)
Tek süreç hem **her 6 saatte tarar** hem de **Telegram'dan komut alır**. Bot yalnızca `.env` içindeki `TELEGRAM_CHAT_ID`'ye cevap verir.
```
chmod +x android/start_loop.sh
mkdir -p ~/.termux/boot
cp android/start_loop.sh ~/.termux/boot/start-jobhunter.sh
chmod +x ~/.termux/boot/start-jobhunter.sh
nohup sh ~/.termux/boot/start-jobhunter.sh > /dev/null 2>&1 &
```
Telegram'da botunuza **/start** yazın. (Chat ID'nizi henüz yazmadıysanız bot size ID'nizi söyler; `.env`'ye yazıp botu yeniden başlatın: `pkill -f bot.py` sonra son komutu tekrar çalıştırın.) Telefon açılınca Termux:Boot botu kendiliğinden başlatır.

**Komutlar:** `/yeni` `/en` `/yaklasan` `/tcdd` `/kamu` `/ozel` `/kontrol` `/listem` `/kapanan` (linkli listeler) · `/ilan 12` (ayrıntı + butonlar) · `/takipet 12` `/basvuracagim 12` `/basvurdum 12` `/sonuc 12` `/ilgilenmiyorum 12` · `/tara` (şimdi tara) · `/durum` · `/kaynaklar` · `/esik 70` · `/haftalik`.
Yeni ilan bildirimlerinin altında da **Takip et / Başvuracağım / Başvurdum / İlgilenmiyorum** butonları çıkar.

**Kontrol:** `tail -n 20 logs/jobhunter.log` ve `logs/bot.out`. Botu durdurmak: `pkill -f bot.py`.
Alternatif (komutsuz, yalnızca bildirim): `android/run_once.sh` + `termux-job-scheduler --script ~/ai_job_hunter/android/run_once.sh --period-ms 21600000 --network any --persisted true`. İkisini birlikte KULLANMAYIN.
Bot sürekli bağlantı beklediği için wake-lock ve B bölümündeki MIUI ayarları şarttır; bot cevap vermiyorsa önce onları kontrol edin.

## H. Panel (isteğe bağlı)
```
python panel_lite.py
```
Telefon tarayıcısında **http://127.0.0.1:8501** açın (yalnızca bu telefondan erişilir). Filtre, arama ve "Başvuracağım / Başvurdum / İlgilenmiyorum / Takip et" durumları vardır. Durdurmak için Termux'ta **CTRL + C**.

## I. Yedek ve güncelleme
- Otomatik yedekler: `~/ai_job_hunter/backups/`. Telefona ek olarak kopyalamak için: `cp -r backups ~/storage/downloads/jobhunter_yedek`
- Yeni sürüm zip'ini aynı şekilde `unzip -o` ile açın; `.env`, `data/` ve `backups/` dosyalarınız silinmez (zip bunları içermez).

## J. Sorun giderme
| Belirti | Çözüm |
|---|---|
| `Process completed (signal 9)` | MIUI/Android öldürdü: B bölümü; gerekirse Yöntem 2. |
| Bildirim gelmiyor | `.env` token/chat id; `python main.py --demo` ile deneyin; önce botunuza mesaj yazmış olmalısınız. |
| `pip` hata veriyor | `pkg install -y python-pip` sonra tekrar; paket kurmak için Wi‑Fi kullanın. |
| `ModuleNotFoundError` | `cd ~/ai_job_hunter` içinde olduğunuzdan emin olun. |
| "Başka bir çalışma sürüyor" | Normal; 3 saatten eski kilit otomatik silinir. |
| Hiç ilan gelmiyor | `sources.json` kapalıdır; F bölümünü yapın. Log: `logs/jobhunter.log`. |
Pil: Yöntem 2'de wake-lock CPU'yu uyanık tutar; Termux bildiriminden "wake lock" kapatılabilir ama bu MIUI'de güvenilirliği düşürür.
