"""Yapılandırma: tüm gizli bilgiler .env dosyasından okunur, koda yazılmaz."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # python-dotenv yoksa ortam değişkenleri yine okunur
    pass

BASE_DIR = Path(__file__).resolve().parent


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "evet", "yes")


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        return float(raw.replace(",", "."))
    except ValueError:
        return default


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


DB_PATH = Path(os.getenv("DB_PATH", BASE_DIR / "data" / "jobs.db"))
LOG_DIR = BASE_DIR / "logs"
BACKUP_DIR = BASE_DIR / "backups"
LOCK_FILE = BASE_DIR / "data" / "run.lock"

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
SMTP = {
    "host": os.getenv("SMTP_HOST", ""), "port": _int("SMTP_PORT", 465),
    "user": os.getenv("SMTP_USER", ""), "password": os.getenv("SMTP_PASSWORD", ""),
    "to": os.getenv("EMAIL_TO", ""),
}
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-haiku-5-5")
MAX_LLM_CALLS_PER_RUN = _int("MAX_LLM_CALLS_PER_RUN", 15)
LLM_MAX_CHARS = 12000  # modele gönderilecek en fazla ilan metni uzunluğu (maliyet kontrolü)

NOTIFY_MIN_SCORE = _int("NOTIFY_MIN_SCORE", 60)
CHECK_EVERY_HOURS = _int("CHECK_EVERY_HOURS", 6)
ENABLE_ILAN_GOV = _bool("ENABLE_ILAN_GOV", False)

PROFILE = {
    "country": "TR",
    "education": "onlisans",
    "department": "Raylı Sistemler Elektrik-Elektronik",
    "kpss_score": _float("KPSS_SCORE", 77.09),
    "kpss_score_type": os.getenv("KPSS_SCORE_TYPE", "P93").upper(),
    "age": _int("AGE", 21),
    "military_done": False,
    "gender": os.getenv("GENDER", "").strip().lower(),  # "erkek" | "kadin" | ""
    "qual_codes": [c.strip() for c in os.getenv("MY_QUAL_CODES", "3001").split(",") if c.strip()],
    "qual_codes_verified": _bool("QUAL_CODES_VERIFIED", False),
    # Mezuniyet alanınızın ÖSYM AİS kaydı kontrol edilip kesinleşirse true yapın: kod uyuşmazlığı o zaman "engel" sayılır.
    "qual_codes_authoritative": _bool("AREA_CODE_VERIFIED", False),
    "home_city": "Bursa",
    "near_cities": ["Bilecik", "Balıkesir", "Kocaeli", "Sakarya", "Yalova", "İstanbul"],
}

# Kurum tercihleri (anahtar kelime -> temel puan; 20 puan üzerinden kullanılır)
PRIORITY_INSTITUTIONS = ["tcdd taşımacılık", "tcdd", "devlet demiryolları"]
RAIL_KEYWORDS = ["raylı", "demiryol", "tcdd", "metro", "tramvay", "sinyal", "katener", "elektrifikasyon"]
RELEVANT_TITLE_KEYWORDS = ["tekniker", "teknik", "memur", "elektrik", "elektronik", "bakım", "hat", "sinyal", "raylı"]
# Emniyet-kritik görev ipuçları: bunlarda sağlık/göz şartları ağırdır, genel memur kadrosundan ayrı işaretlenir.
SAFETY_CRITICAL_KEYWORDS = ["makinist", "tren trafik", "hareket memuru", "tren hazırlama", "manevra", "emniyet", "yol bekçi", "gar ",
                            # ÖSYM KPSS-2026/1 kılavuzu 2.5 ve 2.15: Demiryolu Emniyet Kritik Görevler Yönetmeliği kapsamındaki unvanlar
                            "hat bakım onarım", "sürveyan", "vagon teknisyeni", "lojistik memuru", "kondüktör", "kondoktör"]
