"""Telegram bot + zamanlayıcı (tek süreç).  Çalıştırma:  python bot.py

• Her CHECK_EVERY_HOURS saatte ilanları tarar, uygun yeni ilanları linkiyle gönderir (butonlarla).
• Telegram'dan komut alır: /yeni /en /yaklasan /tcdd /kontrol /ilan 12 /tara /durum ...
• YALNIZCA .env içindeki TELEGRAM_CHAT_ID'ye cevap verir (başkaları komut veremez)."""
from __future__ import annotations

import html
import json
import logging
import re
import sys
import threading
import time
from datetime import datetime

import requests

import config
import notifier
from database import DB, run_lock
from main import run_once, setup_logging, weekly_digest
from panel_lite import ST, VIEWS
from sources.base import Http
from sources.registry import build_sources

log = logging.getLogger("bot")
e = lambda x: html.escape(str(x if x not in (None, "") else "—"))

HELP = ("🤖 <b>İş İlanı Botu</b>\n\n<b>Listeler</b> (linkleriyle):\n/yeni — son 3 günde bulunanlar\n/en — en yüksek puanlılar\n"
        "/yaklasan — süresi yaklaşanlar\n/tcdd — TCDD ilanları\n/kamu — diğer kamu\n/ozel — özel sektör\n/kilavuz — ÖSYM kılavuzunda kodlarınıza uyan kadrolar (/kilavuz tcdd)\n/kodlarim — nitelik kodlarınız\n/guvenlik — askeri/polis/zabıta/jandarma\n/genel — 3001 genel önlisans (herhangi bir önlisans)\n/ara kelime — kayıtlı ilanlarda ara\n/kontrol — şartları kontrol edilmeli\n"
        "/listem — takip ettiklerim/başvurduklarım\n/kapanan — kapanan/uygun olmayan\n\n<b>İlan işlemleri</b>:\n/ilan 12 — ayrıntı + butonlar\n"
        "/takipet 12 · /basvuracagim 12 · /basvurdum 12 · /sonuc 12 · /ilgilenmiyorum 12\n\n<b>Sistem</b>:\n/tara — şimdi tara\n/durum — özet\n"
        "/kaynaklar — kaynak sağlığı\n/esik 70 — bildirim için en düşük puan\n/haftalik — haftalık özet\n\n"
        "<i>Başvuru otomatik yapılmaz; şartları resmî ilandan teyit edin.</i>")
VIEW_CMDS = {"guvenlik": "guvenlik", "genel": "genel", "yeni": "yeni", "en": "en", "yaklasan": "yaklasan", "tcdd": "tcdd", "kamu": "kamu", "ozel": "ozel",
             "kontrol": "kontrol", "listem": "takipte", "kapanan": "kapanan"}
STATUS_CMDS = {"takipet": "takip", "basvuracagim": "basvuracagim", "basvurdum": "basvurdum", "sonuc": "sonuc_bekliyorum", "ilgilenmiyorum": "ilgilenmiyorum"}


# ----------------------------------------------------------------------------- Telegram API
def api(method: str, _timeout: int = 35, **params):
    """Telegram çağrısı. Hata mesajlarında token sızmasın diye yalnızca hata türü loglanır."""
    try:
        r = requests.post(f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/{method}", json=params, timeout=_timeout)
        data = r.json()
        if not data.get("ok"):
            log.warning("Telegram %s hatası: %s", method, str(data.get("description"))[:120])
            return None
        return data
    except (requests.RequestException, ValueError) as ex:
        log.warning("Telegram %s bağlantı hatası (%s)", method, type(ex).__name__)
        return None


def send_msg(chat_id, text: str, markup=None) -> bool:
    p = {"chat_id": chat_id, "text": text[:4000], "parse_mode": "HTML", "disable_web_page_preview": True}
    if markup:
        p["reply_markup"] = markup
    return api("sendMessage", **p) is not None


# ----------------------------------------------------------------------------- komutlar
def short(r) -> str:
    return (f"<b>#{r['id']}</b> {e(r['score'])}/100 • {e(r['institution'])}\n{e(r['title'])} ({e(r['city'])})\n"
            f"{e(r['status'])} • Son: {e(r['deadline'] or 'doğrulanamadı')}\n{e(r['url'])}")


def list_view(db: DB, key: str, per_msg: int = 5, limit: int = 15) -> list:
    name, where, order = VIEWS[key]
    rows = db.conn.execute(f"SELECT * FROM ads WHERE {where} ORDER BY {order} LIMIT ?", (limit,)).fetchall()
    if not rows:
        return [(f"<b>{e(name)}</b>: bu görünümde ilan yok.\n(Kaynaklar açık mı? /kaynaklar, /durum)", None)]
    out = [(f"<b>{e(name)}</b> — {len(rows)} ilan (ayrıntı için /ilan NO)", None)]
    for i in range(0, len(rows), per_msg):
        out.append(("\n\n".join(short(r) for r in rows[i:i + per_msg]), None))
    return out


def handle_text(text: str, db: DB, ctx: dict) -> list:
    """Komut metnini [(mesaj, buton)] listesine çevirir. ctx: {'scan': fn(chat)->bool, 'chat': id, 'send': fn(text)}"""
    parts = text.strip().split()
    if not parts or not parts[0].startswith("/"):
        return [("Komutlar için /yardim yazın.", None)]
    cmd = parts[0][1:].split("@")[0].lower()
    arg = parts[1] if len(parts) > 1 else ""
    if cmd in ("start", "yardim", "help"):
        return [(HELP, None)]
    if cmd in VIEW_CMDS:
        return list_view(db, VIEW_CMDS[cmd])
    if cmd in ("ilan", *STATUS_CMDS):
        if not arg.isdigit():
            return [(f"Kullanım: /{cmd} 12  (ilan numarası listelerde #12 olarak görünür)", None)]
        r = db.conn.execute("SELECT * FROM ads WHERE id=?", (int(arg),)).fetchone()
        if not r:
            return [("Bu numarada ilan bulunamadı.", None)]
        if cmd == "ilan":
            return [(notifier.format_ad(dict(r), "detail"), notifier.ad_keyboard(r["id"]))]
        db.set_user_status(r["id"], STATUS_CMDS[cmd])
        return [(f"✔ #{r['id']} → {ST[STATUS_CMDS[cmd]]}", None)]
    if cmd == "kilavuz":
        import osym_guide as g
        rows = g.query_matches(db, limit=12, only_prio=0 if arg.lower() == "tcdd" else None)
        if not rows:
            return [("Kılavuz verisi yok veya kodlarınıza uyan kadro bulunamadı. Yeni KPSS kılavuzu çıkınca bot kendisi okur; elle yüklemek için README_GITHUB.md'deki 'Kılavuz PDF' bölümüne bakın.", None)]
        return [(f"📘 Kodlarınıza uyan kadrolar ({rows[0]['guide']}):\n\n" + g.format_rows(rows[:6]), None)] + \
               ([(g.format_rows(rows[6:]), None)] if len(rows) > 6 else [])
    if cmd == "kodlarim":
        import osym_guide as g
        mine = sorted(config.PROFILE["qual_codes"])
        lines = [f"<b>{c}</b>: {e(g.VERIFIED_CODES.get(c, 'resmî tabloda doğrulanmadı'))}" for c in mine]
        return [("🎓 Nitelik kodlarınız (ÖSYM önlisans tablolarında doğrulananlar):\n" + "\n".join(lines)
                 + "\n\n⚠️ Sizin için geçerli olan, ÖSYM AİS'teki kayıtlı mezuniyet alanınıza bağlıdır; ais.osym.gov.tr'den kontrol edin. "
                   "Bazı kadrolar başka kodlar da kabul edebilir; kılavuz tablosundaki 'mezun olunan alan' listesine bakın.", None)]
    if cmd == "ara":
        from analyzer import fold
        key = fold(" ".join(parts[1:]))
        if len(key) < 3:
            return [("Kullanım: /ara zabıta  (en az 3 harf)", None)]
        rows = [r for r in db.conn.execute("SELECT * FROM ads ORDER BY score DESC LIMIT 1000")
                if key in fold(f"{r['institution']} {r['title']} {r['city']}")][:12]
        if not rows:
            return [("Kayıtlı ilanlar arasında bulunamadı.", None)]
        return [("\n\n".join(short(r) for r in rows[i:i + 5]), None) for i in range(0, len(rows), 5)]
    if cmd == "tara":
        return [("🔎 Tarama başladı; bitince sonucu yazacağım." if ctx["scan"](ctx["chat"]) else "Zaten bir tarama sürüyor.", None)]
    if cmd == "durum":
        c = lambda q: db.conn.execute(q).fetchone()[0]
        last = db.conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
        elig = c("SELECT COUNT(*) FROM ads WHERE lifecycle='active' AND status IN ('Şartları karşılıyor','Muhtemelen karşılıyor')")
        txt = (f"📊 Toplam ilan: {c('SELECT COUNT(*) FROM ads')}\nAçık ve uygun görünen: {elig}\n"
               f"Bildirim eşiği: {db.get_setting('notify_min', config.NOTIFY_MIN_SCORE)}/100\nTarama aralığı: {config.CHECK_EVERY_HOURS} saat\n"
               f"Son tarama: {e(last['finished'] if last else 'henüz yok')}")
        return [(txt, None)]
    if cmd == "kaynaklar":
        rows = db.conn.execute("SELECT * FROM source_health").fetchall()
        if not rows:
            return [("Henüz kaynak çalışmadı veya hiç kaynak etkin değil. sources.json içinde enabled=true yapın.", None)]
        return [("\n".join(f"{'✅' if r['consecutive_failures'] == 0 else '❌'} {e(r['source'])} — art arda hata: {r['consecutive_failures']}"
                           + (f"\n   {e(r['last_error'])}" if r["last_error"] else "") for r in rows), None)]
    if cmd == "esik":
        if not arg.isdigit() or not 0 <= int(arg) <= 100:
            return [("Kullanım: /esik 70  (0–100)", None)]
        db.set_setting("notify_min", int(arg))
        return [(f"✔ Bildirim eşiği {int(arg)}/100 yapıldı.", None)]
    if cmd == "haftalik":
        weekly_digest(db, ctx["send"])
        return []
    return [("Bilinmeyen komut. /yardim", None)]


# ----------------------------------------------------------------------------- tarama
class Scanner:
    def __init__(self):
        self.busy = threading.Lock()

    def start(self, chat=None) -> bool:
        if not self.busy.acquire(blocking=False):
            return False
        threading.Thread(target=self._run, args=(chat,), daemon=True).start()
        return True

    def _run(self, chat):
        db = None
        try:
            db = DB()
            http = Http()
            srcs = build_sources(http)
            with run_lock():
                st = run_once(db, srcs, http, notifier.notify)
                try:
                    db.backup()
                except Exception as ex:
                    log.warning("Yedekleme başarısız: %s", type(ex).__name__)
            if chat:
                msg = (f"✅ Tarama bitti: yeni {st['new']}, güncellenen {st['updated']}, gönderilen bildirim {st['notified']}.")
                if not srcs:
                    msg += "\n⚠️ Etkin kaynak yok (sources.json)."
                if st["errors"]:
                    msg += "\n⚠️ Hatalar:\n" + "\n".join(e(x)[:150] for x in st["errors"][:3])
                send_msg(chat, msg)
        except RuntimeError as ex:
            log.warning(str(ex))
        except Exception as ex:
            log.exception("Tarama hatası")
            send_msg(config.TELEGRAM_CHAT_ID, f"⚠️ Tarama hata verdi: {type(ex).__name__}")
        finally:
            if db:
                db.close()
            self.busy.release()


def scheduler(scanner: Scanner):
    """Her CHECK_EVERY_HOURS saatte tarama; pazartesi 09:00'dan sonra haftalık özet. Zaman bilgisi yeniden başlatmada korunur."""
    db = DB()
    while True:
        try:
            now = time.time()
            if now - float(db.get_setting("last_scan", 0)) >= config.CHECK_EVERY_HOURS * 3600:
                if scanner.start(None):
                    db.set_setting("last_scan", now)
            t = datetime.now()
            if t.weekday() == 0 and t.hour >= 9 and db.get_setting("last_weekly") != t.date().isoformat():
                weekly_digest(db, lambda x: send_msg(config.TELEGRAM_CHAT_ID, x))
                db.set_setting("last_weekly", t.date().isoformat())
        except Exception as ex:
            log.warning("Zamanlayıcı hatası: %s", type(ex).__name__)
        time.sleep(60)


# ----------------------------------------------------------------------------- güncelleme işleme
def process_update(u: dict, db: DB, ctx_base: dict):
    chat_ok = lambda cid: bool(config.TELEGRAM_CHAT_ID) and str(cid) == str(config.TELEGRAM_CHAT_ID)
    cq = u.get("callback_query")
    if cq:
        cid = (cq.get("message") or {}).get("chat", {}).get("id")
        if not chat_ok(cid):
            return
        m = re.fullmatch(r"st:(\d+):(\w+)", cq.get("data", ""))
        if m and m.group(2) in ST and db.conn.execute("SELECT 1 FROM ads WHERE id=?", (int(m.group(1)),)).fetchone():
            db.set_user_status(int(m.group(1)), m.group(2))
            api("answerCallbackQuery", callback_query_id=cq["id"], text=f"Kaydedildi: {ST[m.group(2)]}")
        else:
            api("answerCallbackQuery", callback_query_id=cq["id"], text="Geçersiz işlem")
        return
    msg = u.get("message") or {}
    cid, text = msg.get("chat", {}).get("id"), msg.get("text", "")
    if cid is None or not text:
        return
    if not chat_ok(cid):
        if text.startswith(("/start", "/id")):  # kurulum kolaylığı: kendi chat ID'nizi öğrenin
            send_msg(cid, f"Chat ID'niz: <code>{cid}</code>\nBunu .env dosyasında TELEGRAM_CHAT_ID= satırına yazıp botu yeniden başlatın.")
        return
    ctx = {**ctx_base, "chat": cid, "send": lambda t: send_msg(cid, t)}
    for t, mk in handle_text(text, db, ctx):
        send_msg(cid, t, mk)


def main() -> int:
    setup_logging()
    if not config.TELEGRAM_BOT_TOKEN:
        print("HATA: .env içinde TELEGRAM_BOT_TOKEN boş.")
        return 1
    if not config.TELEGRAM_CHAT_ID:
        print("UYARI: TELEGRAM_CHAT_ID boş. Botunuza Telegram'dan /start yazın; chat ID'nizi söyleyecek. Sonra .env'ye yazıp yeniden başlatın.")
    db = DB()
    scanner = Scanner()
    ctx = {"scan": scanner.start}
    api("deleteWebhook")
    if config.TELEGRAM_CHAT_ID:
        threading.Thread(target=scheduler, args=(scanner,), daemon=True).start()
        send_msg(config.TELEGRAM_CHAT_ID, "🤖 Bot başladı. Komutlar için /yardim")
    offset = int(db.get_setting("bot_offset", 0))
    fails = 0
    log.info("Bot dinlemede.")
    while True:
        res = api("getUpdates", _timeout=40, offset=offset, timeout=25, allowed_updates=["message", "callback_query"])
        if res is None:
            fails += 1
            time.sleep(min(5 * fails, 60))
            continue
        fails = 0
        for u in res.get("result", []):
            offset = u["update_id"] + 1
            try:
                process_update(u, db, ctx)
            except Exception as ex:
                log.warning("Güncelleme işlenemedi: %s", type(ex).__name__)
            db.set_setting("bot_offset", offset)


if __name__ == "__main__":
    sys.exit(main())
