"""Telegram chat ID'nizi bulur. Önce botunuza Telegram'dan herhangi bir mesaj yazın, sonra: python get_chat_id.py"""
import sys
import requests
import config

if not config.TELEGRAM_BOT_TOKEN:
    sys.exit(".env içinde TELEGRAM_BOT_TOKEN boş. Önce BotFather'dan aldığınız tokeni yazın.")
r = requests.get(f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/getUpdates", timeout=20)
r.raise_for_status()
chats = {u["message"]["chat"]["id"]: u["message"]["chat"].get("first_name", "") for u in r.json().get("result", []) if "message" in u}
if not chats:
    sys.exit("Mesaj bulunamadı. Botunuza Telegram'dan bir mesaj yazıp tekrar deneyin.")
for cid, name in chats.items():
    print(f"CHAT ID: {cid}  ({name})  -> bunu .env içinde TELEGRAM_CHAT_ID= satırına yazın")
