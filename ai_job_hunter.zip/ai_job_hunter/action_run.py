"""GitHub Actions tek tur (telefon/sunucu gerekmez):
1) bekleyen Telegram komutlarını işler  2) zamanı geldiyse ilanları tarar  3) pazartesi haftalık özet  4) veritabanını kapatır.
Ek: PROBE_URL / CHECK_SOURCES ortam değişkenleri (workflow'u elle çalıştırırken) sonucu Telegram'a yazar."""
from __future__ import annotations

import contextlib
import html
import io
import logging
import os
import sys
import time
from datetime import datetime

import bot
import config
import osym_guide
import notifier
from database import DB, run_lock
from main import probe, run_once, setup_logging, weekly_digest
from sources.base import Http
from sources.registry import build_sources

log = logging.getLogger("action")
UPDATES = ["message", "callback_query"]


def process_pending(db: DB, flags: dict):
    ctx = {"scan": lambda chat: (flags.update(scan=True, chat=chat) or True)}
    offset = int(db.get_setting("bot_offset", 0))
    for _ in range(10):  # en fazla ~1000 bekleyen güncelleme
        res = bot.api("getUpdates", _timeout=30, offset=offset, timeout=0, limit=100, allowed_updates=UPDATES)
        if not res or not res.get("result"):
            break
        for u in res["result"]:
            offset = u["update_id"] + 1
            try:
                bot.process_update(u, db, ctx)
            except Exception as ex:
                log.warning("Güncelleme işlenemedi: %s", type(ex).__name__)
            db.set_setting("bot_offset", offset)


def do_scan(db: DB, chat) -> None:
    http = Http()
    srcs = build_sources(http)
    try:
        with run_lock():
            st = run_once(db, srcs, http, notifier.notify)
        db.set_setting("last_scan", time.time())
    except RuntimeError as ex:
        log.warning(str(ex))
        return
    if chat:
        msg = f"✅ Tarama bitti: yeni {st['new']}, güncellenen {st['updated']}, gönderilen bildirim {st['notified']}."
        if not srcs:
            msg += "\n⚠️ Etkin kaynak yok (sources.json)."
        if st["errors"]:
            msg += "\n⚠️ Hatalar:\n" + "\n".join(html.escape(x)[:150] for x in st["errors"][:3])
        bot.send_msg(chat, msg)


def main() -> int:
    setup_logging()
    if not config.TELEGRAM_BOT_TOKEN:
        print("HATA: TELEGRAM_BOT_TOKEN secret'ı tanımlı değil.")
        return 1
    chat = config.TELEGRAM_CHAT_ID
    db = DB()
    try:
        # Elle çalıştırmada kaynak denetimi / adres sondalama (sonuç Telegram'a gelir)
        url = os.getenv("PROBE_URL", "").strip()
        if url and chat:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                probe(url)
            bot.send_msg(chat, "🔎 <b>Sonda sonucu</b>\n<pre>" + html.escape(buf.getvalue()[:3500]) + "</pre>")
        if os.getenv("CHECK_SOURCES", "").lower() == "true" and chat:
            lines = []
            srcs = build_sources(Http())
            for s in srcs:
                try:
                    lines.append(f"OK {s.name}: {len(s.fetch())} kayıt")
                except Exception as ex:
                    lines.append(f"HATA {s.name}: {ex}")
            bot.send_msg(chat, "🧪 <b>Kaynak kontrolü</b>\n<pre>" + html.escape("\n".join(lines) or "Etkin kaynak yok")[:3500] + "</pre>")

        my_codes = set(config.PROFILE["qual_codes"])
        if os.getenv("GUIDE_FILES", "").lower() == "true" and chat:
            try:
                osym_guide.process_files(db, os.getenv("GUIDE_DIR", "../kilavuz"), my_codes, lambda t: bot.send_msg(chat, t))
            except Exception as ex:
                log.exception("Kılavuz dosyaları işlenemedi")
                bot.send_msg(chat, f"⚠️ Kılavuz PDF'leri işlenemedi: {type(ex).__name__}")

        flags = {"scan": False, "chat": None}
        process_pending(db, flags)
        due = time.time() - float(db.get_setting("last_scan", 0)) >= config.CHECK_EVERY_HOURS * 3600 - 600
        if due or flags["scan"]:
            do_scan(db, flags["chat"])
            if chat:  # yeni ÖSYM kılavuzu yayımlandı mı?
                try:
                    osym_guide.check_new_guides(db, Http(), my_codes, lambda t: bot.send_msg(chat, t))
                except Exception as ex:
                    log.warning("Kılavuz izleme hatası: %s", type(ex).__name__)
        t = datetime.now()
        if chat and t.weekday() == 0 and t.hour >= 9 and db.get_setting("last_weekly") != t.date().isoformat():
            weekly_digest(db, lambda x: bot.send_msg(chat, x))
            db.set_setting("last_weekly", t.date().isoformat())
    except Exception as ex:
        log.exception("Çalışma hatası")
        if chat:
            bot.send_msg(chat, f"⚠️ Çalışma hata verdi: {type(ex).__name__}. GitHub → Actions sekmesinden günlüğe bakın.")
        return 1
    finally:
        try:
            db.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
