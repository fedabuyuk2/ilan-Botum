# GitHub (ücretsiz) ile Telegram Botu — Kurulum

Telefona/bilgisayara program kurmadan çalışır. Kod GitHub'ın sunucusunda **30 dakikada bir** çalışır: Telegram komutlarınızı yanıtlar, **6 saatte bir** ilanları tarar, uygun ilanı linkiyle size yollar.

Bilmeniz gerekenler:
- Komutlara cevap **anında değil, en geç ~30 dakikada** gelir (GitHub bazen daha da geciktirir). Anında cevap için: GitHub'da Actions → Ilan Botu → Run workflow.
- Depo **Private (özel)** olmalı. Özel depolarda aylık ücretsiz dakika sınırı vardır (şu an 2000 dk; güncelini GitHub'dan kontrol edin). Bu kurulum ayda yaklaşık 1500 dk harcar; sınır dolarsa `*/30` yerine `0 * * * *` (saatte bir) yazın.
- Veritabanı, depodaki `state` dalında tutulur (tek commit, şişmez).

## ÖSYM kılavuzu (nitelik kodları ve kadrolar)
**Doğrulananlar (resmî ÖSYM PDF'lerinden):** `3001` = "Herhangi bir önlisans programından mezun olmak" (KPSS-2026/1 kılavuzu); `3206` = "Raylı Sistemler Elektrik-Elektronik Teknolojisi veya Raylı Sistemler Elektrik ve Elektronik Teknolojisi önlisans programından mezun olmak" (ÖSYM ön lisans nitelik tablosu, KPSS-2025/2'de görüldü; 2026/2 tablosunda da kontrol edin). Bir kadroda birden fazla program/alan kodu varsa **birini karşılamak yeterlidir**; cinsiyet, sertifika ve özel şart kodları ise ayrıca sağlanmalıdır (bot bunları yorumlamaz, "ek şart kodları" diye işaretler).
**Hâlâ sizin kontrol etmeniz gereken:** ÖSYM'de kayıtlı mezuniyet alanınız (ais.osym.gov.tr). Bu doğrulanınca workflow dosyasında `AREA_CODE_VERIFIED: "true"` yapın.

**Telegram komutları:** `/kodlarim`, `/kilavuz`, `/kilavuz tcdd`.

**Otomatik izleme:** Yeni kılavuz sayfası (tahmini adres: osym.gov.tr/kpss20262-...) açılırsa bot PDF'leri indirip okur ve size özet yollar. Adres tahmin olduğu için tutmayabilir; bu yüzden elle yöntem de var:
1. ÖSYM sitesinden **Tablo-2 (ön lisans)** PDF'ini ve (isteğe bağlı) **ön lisans nitelik kodları** PDF'ini indirin.
2. Depoda **Add file → Create new file**, ad: `kilavuz/OKU.txt` (içine herhangi bir yazı) → Commit. Sonra `kilavuz` klasörüne girip **Add file → Upload files** ile PDF'leri yükleyin. Dosya adlarında `tablo2` ve `nitelik` geçsin; kılavuz adı için `KPSS-2026-2` ifadesi ekleyin (ör. `tablo2_KPSS-2026-2.pdf`). Tarayıcı yüklemesi dosya başına yaklaşık 25 MB ile sınırlıdır.
3. **Actions → Ilan Botu → Run workflow → guide_files** kutusunu işaretleyin. Telegram'a "kılavuz işlendi" özeti gelir; okunan kadro sayısı beklenenden azsa bana bildirin (ayrıştırıcı gerçek PDF'lerle henüz denenmedi).
