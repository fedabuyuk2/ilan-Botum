"""AI Job Hunter — ana uygulama.

Kullanım:
  python main.py --demo --dry-run     # uydurma örnek ilanlarla deneme (ağ ve Telegram gerekmez)
  python main.py --probe URL          # bir sitenin robots.txt / RSS durumunu kontrol et
  python main.py --check-sources      # etkin kaynakların erişilebilirliğini raporla
  python main.py --once               # bir tur çalıştır (zamanlayıcı/n8n bunu çağırır)
  python main.py --loop               # kendi içinde her CHECK_EVERY_HOURS saatte bir çalış
  python main.py --weekly             # haftalık özet gönder
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from datetime import date, datetime, timedelta
from logging.handlers import RotatingFileHandler
from typing import Callable, Optional

import config
import notifier
from analyzer import ELIGIBLE_STATUSES, analyze, fold
from database import DB, run_lock
from sources.base import Http, SourceError
from sources.demo import DemoSource
from sources.registry import build_sources

log = logging.getLogger("jobhunter")
PREFILTER = ["tcdd", "demiryol", "raylı", "tekniker", "teknik", "önlisans", "ön lisans", "elektrik", "elektronik", "memur", "kpss",
             "sinyal", "bakım", "metro", "tramvay", "mekatronik", "hat ", "işletmeni", "teknisyen", "sözleşmeli", "personel alım",
             "zabıta", "polis", "jandarma", "astsubay", "uzman erbaş", "bekçi", "korucu", "sahil güvenlik", "milli savunma", "subay",
             "muvazzaf", "emniyet", "askeri", "komiser", "3001"]
MAX_DETAIL_FETCH = 40   # tur başına en fazla detay sayfası isteği (kaynaklara nazik davranmak için)
RECHECK_HOURS = 12      # bilinen ilanın detayı bu süreden önce yeniden çekilmez
EXCLUDE_USER_STATUSES = ("ilgilenmiyorum", "basvurdum", "sonuc_bekliyorum")


def setup_logging():
    config.LOG_DIR.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh = RotatingFileHandler(config.LOG_DIR / "jobhunter.log", maxBytes=1_000_000, backupCount=5, encoding="utf-8")
    sh = logging.StreamHandler(sys.stdout)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for h in (fh, sh):
        h.setFormatter(fmt)
        h.addFilter(notifier.SecretFilter())
        root.addHandler(h)


def relevant(raw) -> bool:
    return any(fold(k) in fold(raw.title + " " + raw.institution) for k in PREFILTER)


def _fresh(db: DB, raw) -> bool:
    """İlan zaten analiz edilmiş ve yakın zamanda kontrol edilmişse detay sayfasını yeniden çekme."""
    ex = db.find_existing(raw.source, raw.source_id, raw.institution, raw.title, raw.city)
    if not ex or ex["score"] is None or ex["lifecycle"] != "active":
        return False
    try:
        age = datetime.now() - datetime.fromisoformat(ex["last_checked"])
    except ValueError:
        return False
    return age < timedelta(hours=RECHECK_HOURS) and bool(ex["notified"] or ex["status"])


def _row(db: DB, ad_id: int) -> dict:
    return dict(db.conn.execute("SELECT * FROM ads WHERE id=?", (ad_id,)).fetchone())


def run_once(db: DB, sources: list, http, send: Callable[[str], bool], demo: bool = False,
             today: Optional[date] = None, use_llm: bool = True, llm_client=None) -> dict:
    today = today or date.today()
    started = datetime.now().isoformat(timespec="seconds")
    stats = {"new": 0, "updated": 0, "notified": 0, "errors": [], "sources_ok": 0, "sources_failed": 0}
    llm_left = config.MAX_LLM_CALLS_PER_RUN
    detail_left = MAX_DETAIL_FETCH

    for src in sources:
        try:
            ads = src.fetch()
            db.record_source(src.name, True)
            stats["sources_ok"] += 1
        except Exception as e:  # SourceError veya beklenmeyen hata: veri uydurulmaz, rapora yazılır
            msg = f"{src.name}: {e}"
            log.error("Kaynak hatası — %s", msg)
            stats["errors"].append(msg)
            stats["sources_failed"] += 1
            db.record_source(src.name, False, str(e))
            if db.should_alert_source(src.name):
                send(f"⚠️ <b>Kaynağa art arda erişilemiyor</b>\n{src.name}\nSon hata: {str(e)[:200]}\nBu kaynaktan veri doğrulanamıyor.")
            continue

        for raw in ads:
            try:
                if not demo and not relevant(raw):
                    continue
                text = raw.text or ""
                detail_failed = False
                if http is not None and not demo and len(text) < 500 and _fresh(db, raw):
                    continue
                if len(text) < 500 and raw.url and not demo and http is not None:
                    if detail_left <= 0:
                        continue  # bütçe doldu; bu ilan sonraki turda işlenir
                    detail_left -= 1
                    try:
                        text = (text + "\n" + http.page_text(raw.url)).strip()
                    except SourceError as e:
                        detail_failed = True
                        stats["errors"].append(f"{raw.source}: detay alınamadı: {e}")
                ad = {"source": raw.source, "source_id": raw.source_id, "institution": raw.institution, "title": raw.title,
                      "city": raw.city, "category": raw.category, "url": raw.url, "deadline": raw.deadline}
                row, change = db.upsert_ad(ad, text)
                if change == "new":
                    stats["new"] += 1
                elif change == "changed":
                    stats["updated"] += 1
                if change in ("new", "changed") or row["score"] is None:
                    llm_on = use_llm and llm_left > 0 and bool(config.ANTHROPIC_API_KEY or llm_client)
                    res, ex = analyze({**ad, "institution": row["institution"]}, text, today=today, use_llm=llm_on, llm_client=llm_client)
                    if llm_on:
                        llm_left -= 1
                    if detail_failed:
                        res["warnings"].append("İlan metni alınamadı; değerlendirme yalnızca başlığa dayanıyor (doğrulanmadı).")
                        if res["status"] in ELIGIBLE_STATUSES:
                            res["status"] = "Ek doğrulama gerekli"
                    diffs = db.save_analysis(row["id"], res, ex, meta={"title": raw.title, "city": raw.city or None, "url": raw.url})
                    cur = _row(db, row["id"])
                    stats["notified"] += _decide_notifications(db, cur, change, diffs, send, demo)
                else:
                    # İçerik değişmedi; ancak önceki turda bildirimi başarısız olmuş ilanı yeniden dene
                    cur = _row(db, row["id"])
                    if not cur["notified"]:
                        stats["notified"] += _decide_notifications(db, cur, change, [], send, demo)
            except Exception as e:
                log.exception("İlan işlenirken hata: %s", raw.title[:80])
                stats["errors"].append(f"{raw.title[:60]}: {type(e).__name__}")

    stats["notified"] += _deadline_reminders(db, send, today, demo)
    _close_expired(db, today)
    db.log_run(started, stats["new"], stats["updated"], stats["notified"], stats["errors"])
    return stats


def _decide_notifications(db: DB, row: dict, change: str, diffs: list[str], send, demo: bool) -> int:
    sec_verify = row["status"] == "Ek doğrulama gerekli" and any(t in (row.get("tags") or "") for t in ("guvenlik", "tcdd"))
    if sec_verify:  # sayfa/menü bağlantılarından gürültü gelmesin: öğrenim düzeyi veya son başvuru tarihi tespit edilmiş olmalı
        try:
            exj = json.loads(row.get("extracted") or "{}")
        except ValueError:
            exj = {}
        sec_verify = bool(exj.get("education_levels") or exj.get("deadline"))
    eligible = (row["status"] in ELIGIBLE_STATUSES or sec_verify) and row["lifecycle"] == "active" and (row["score"] or 0) >= int(db.get_setting("notify_min", config.NOTIFY_MIN_SCORE))
    if row["user_status"] in EXCLUDE_USER_STATUSES:
        return 0
    if not row["notified"]:
        if eligible:
            kind = "priority" if row["score"] >= 90 else "new"
            if send(notifier.format_ad(row, kind, demo=demo)):
                db.mark_notified(row["id"], row["content_hash"])
                return 1
            log.warning("Bildirim gönderilemedi; sonraki turda tekrar denenecek: %s", row["title"][:60])
        return 0
    # Daha önce bildirilmiş ilan: güncelleme / iptal tespiti (aynı içerik için tekrar bildirim yok)
    if row["lifecycle"] == "cancelled" and row["notified_hash"] != "closed:cancelled":
        if send(notifier.format_ad(row, "cancel", diffs, demo=demo)):
            db.mark_notified(row["id"], f"closed:{row['lifecycle']}")
            return 1
    elif change == "changed" and row["content_hash"] != row["notified_hash"] and diffs:
        if send(notifier.format_ad(row, "update", diffs, demo=demo)):
            db.mark_notified(row["id"], row["content_hash"])
            return 1
    return 0


def _deadline_reminders(db: DB, send, today: date, demo: bool) -> int:
    n = 0
    rows = db.conn.execute("""SELECT * FROM ads WHERE lifecycle='active' AND notified=1 AND deadline IS NOT NULL
                              AND (status IN (?,?) OR (status='Ek doğrulama gerekli' AND (tags LIKE '%guvenlik%' OR tags LIKE '%tcdd%')))
                              AND COALESCE(user_status,'') NOT IN ('ilgilenmiyorum','basvurdum','sonuc_bekliyorum')""",
                           ELIGIBLE_STATUSES).fetchall()
    for r in rows:
        left = (date.fromisoformat(r["deadline"]) - today).days
        for kind, lim in (("d1", 1), ("d3", 3)):
            if 0 <= left <= lim and not db.reminder_sent(r["id"], kind):
                if send(notifier.format_ad(dict(r), "reminder", [f"{left} gün kaldı"], demo=demo)):
                    db.add_reminder(r["id"], kind)
                    if kind == "d1":
                        db.add_reminder(r["id"], "d3")
                    n += 1
                break
    return n


def _close_expired(db: DB, today: date):
    with db.tx() as c:
        c.execute("UPDATE ads SET lifecycle='closed' WHERE lifecycle='active' AND deadline IS NOT NULL AND deadline < ?", (today.isoformat(),))


def weekly_digest(db: DB, send) -> bool:
    rows = db.conn.execute("""SELECT * FROM ads WHERE lifecycle='active' AND status IN (?,?)
                              AND COALESCE(user_status,'') != 'ilgilenmiyorum' ORDER BY score DESC LIMIT 10""", ELIGIBLE_STATUSES).fetchall()
    week = (datetime.now() - timedelta(days=7)).isoformat()
    new_cnt = db.conn.execute("SELECT COUNT(*) FROM ads WHERE first_seen>=?", (week,)).fetchone()[0]
    lines = [f"📅 <b>Haftalık İlan Özeti</b>", f"Son 7 günde görülen yeni ilan: {new_cnt}", ""]
    if not rows:
        lines.append("Şu an açık ve uygun görünen ilan yok.")
    for r in rows:
        lines.append(f"• {r['score']}/100 — {r['institution'] or '—'} / {r['title'][:70]} (son: {r['deadline'] or 'doğrulanamadı'})")
    return send("\n".join(lines))


def probe(url: str):
    """Bir adresin robots.txt durumunu ve RSS/Atom bağlantılarını gösterir (Aşama 1 aracı)."""
    from sources.base import make_soup
    h = Http()
    print(f"robots.txt izni: {'EVET' if h.allowed(url) else 'HAYIR / OKUNAMADI'}")
    try:
        r = h.get(url)
        print(f"HTTP {r.status_code}, içerik türü: {r.headers.get('content-type')}")
        soup = make_soup(r.content)
        feeds = [l.get("href") for l in soup.select('link[type*="rss"], link[type*="atom"]')]
        print("RSS/Atom bağlantıları:", feeds or "bulunamadı")
    except SourceError as e:
        print("ERİŞİLEMEDİ:", e)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="AI Job Hunter")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--weekly", action="store_true")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="Mesajları göndermez, ekrana yazar")
    ap.add_argument("--no-llm", action="store_true")
    ap.add_argument("--probe", metavar="URL")
    ap.add_argument("--check-sources", action="store_true")
    a = ap.parse_args(argv)
    setup_logging()

    if a.probe:
        probe(a.probe)
        return 0

    send = (lambda t: (print("\n--- BİLDİRİM (dry-run) ---\n" + t) or True)) if a.dry_run else notifier.notify
    db = DB(config.BASE_DIR / "data" / "demo.db" if a.demo else None)
    http = Http() if not a.demo else None
    sources = [DemoSource()] if a.demo else build_sources(http)

    if a.check_sources:
        if not sources:
            print("Etkin kaynak yok. sources.json içinde enabled=true yapın.")
        for s in sources:
            try:
                print(f"OK   {s.name}: {len(s.fetch())} kayıt")
            except Exception as e:
                print(f"HATA {s.name}: {e}")
        return 0
    if a.weekly:
        return 0 if weekly_digest(db, send) else 1

    def one_round() -> int:
        try:
            with run_lock():
                st = run_once(db, sources, http, send, demo=a.demo, use_llm=not a.no_llm)
                try:
                    db.backup()
                except Exception as e:
                    log.warning("Yedekleme başarısız: %s", e)
        except RuntimeError as e:
            log.warning(str(e))
            print(json.dumps({"skipped": True}))
            return 3
        log.info("Tur bitti: %s", {k: v for k, v in st.items() if k != "errors"})
        print("SUMMARY " + json.dumps(st, ensure_ascii=False))
        if not sources:
            print("UYARI: Etkin kaynak yok. sources.json dosyasını düzenleyin (README Bölüm 7).")
        return 2 if st["sources_failed"] and not st["sources_ok"] and sources else 0

    if a.loop:
        while True:
            try:
                one_round()
            except Exception as e:  # döngü hiçbir koşulda ölmesin
                log.exception("Tur beklenmedik hata verdi")
                send(f"⚠️ İlan botu bir turda hata verdi: {type(e).__name__}. Log dosyasına bakın; döngü devam ediyor.")
            time.sleep(config.CHECK_EVERY_HOURS * 3600)
    return one_round()


if __name__ == "__main__":
    sys.exit(main())
