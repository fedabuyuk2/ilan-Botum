#!/data/data/com.termux/files/usr/bin/sh
# Tek tur çalıştırır (Termux Job Scheduler bunu 6 saatte bir çağırır).
cd "$HOME/ai_job_hunter" || exit 1
python main.py --once >> logs/run.out 2>&1
