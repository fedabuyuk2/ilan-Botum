#!/data/data/com.termux/files/usr/bin/sh
# Telefon açılınca (Termux:Boot) veya elle başlatılır: Telegram botu + zamanlı tarama (tek süreç).
termux-wake-lock
cd "$HOME/ai_job_hunter" || exit 1
python bot.py >> logs/bot.out 2>&1
