"""Basit web paneli (Streamlit). Çalıştırma:  streamlit run panel.py
NOT: Bu dosya bu geliştirme ortamında ÇALIŞTIRILARAK test edilemedi (Streamlit kurulu değildi); ilk çalıştırmada hata görürseniz bildirin."""
import json
import sqlite3

import pandas as pd
import streamlit as st

import config

st.set_page_config(page_title="İş İlanı Takip", layout="wide")
st.title("🚆 İş İlanı Takip Paneli")
conn = sqlite3.connect(config.DB_PATH)
conn.row_factory = sqlite3.Row
df = pd.read_sql_query("SELECT * FROM ads ORDER BY score DESC", conn)
if df.empty:
    st.info("Henüz kayıtlı ilan yok.")
    st.stop()

STATUS = {"takip": "Takip et", "basvuracagim": "Başvuracağım", "basvurdum": "Başvurdum",
          "sonuc_bekliyorum": "Sonuç bekliyorum", "ilgilenmiyorum": "İlgilenmiyorum"}
q = st.text_input("Ara (kurum, kadro, şehir)")
view = st.selectbox("Görünüm", ["Tümü", "Yeni (son 3 gün)", "En yüksek puanlı", "Süresi yaklaşan", "TCDD", "Diğer kamu", "Özel sektör",
                                "Kontrol edilmeli", "Kaydedilen/Başvurulan", "Kapanan/Uygun değil"])
today = pd.Timestamp.today().normalize()
d = df.copy()
if q:
    m = d[["institution", "title", "city"]].fillna("").agg(" ".join, axis=1).str.contains(q, case=False)
    d = d[m]
if view == "Yeni (son 3 gün)":
    d = d[pd.to_datetime(d.first_seen) >= today - pd.Timedelta(days=3)]
elif view == "En yüksek puanlı":
    d = d[(d.lifecycle == "active")].head(20)
elif view == "Süresi yaklaşan":
    dl = pd.to_datetime(d.deadline, errors="coerce")
    d = d[(dl >= today) & (dl <= today + pd.Timedelta(days=7))].sort_values("deadline")
elif view == "TCDD":
    d = d[d.institution.fillna("").str.contains("TCDD|Demiryol", case=False)]
elif view == "Diğer kamu":
    d = d[(d.category == "kamu") & ~d.institution.fillna("").str.contains("TCDD|Demiryol", case=False)]
elif view == "Özel sektör":
    d = d[d.category == "ozel"]
elif view == "Kontrol edilmeli":
    d = d[d.status == "Ek doğrulama gerekli"]
elif view == "Kaydedilen/Başvurulan":
    d = d[d.user_status.isin(["takip", "basvuracagim", "basvurdum", "sonuc_bekliyorum"])]
elif view == "Kapanan/Uygun değil":
    d = d[(d.lifecycle != "active") | (d.status == "Şartları karşılamıyor")]

st.caption(f"{len(d)} ilan")
for _, r in d.iterrows():
    with st.expander(f"{r.score if pd.notna(r.score) else '–'}/100 • {r.institution or '—'} • {r.title} • {r.city or ''}"):
        st.write(f"**Durum:** {r.status} | **Aşama:** {r.lifecycle} | **Son başvuru:** {r.deadline or 'doğrulanamadı'}")
        for x in json.loads(r.reasons or "[]"):
            st.write("• " + x)
        for x in json.loads(r.warnings or "[]"):
            st.warning(x)
        st.markdown(f"[Resmî ilan bağlantısı]({r.url})")
        cur = r.user_status if r.user_status in STATUS else None
        new = st.selectbox("Durumum", [None] + list(STATUS), index=([None] + list(STATUS)).index(cur),
                           format_func=lambda k: "—" if k is None else STATUS[k], key=f"s{r.id}")
        if new != cur:
            conn.execute("UPDATE ads SET user_status=? WHERE id=?", (new, int(r.id)))
            conn.commit()
            st.rerun()
