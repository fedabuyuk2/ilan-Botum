"""Telegram ve e-posta bildirimleri (yeniden deneme + gizli anahtar maskeleme)."""
from __future__ import annotations

import html
import logging
import re
import smtplib
import time
from email.message import EmailMessage
from typing import Optional

import requests

import config

log = logging.getLogger(__name__)


class SecretFilter(logging.Filter):
    """Log satırlarındaki token/şifreleri maskeler."""
    def filter(self, record):
        msg = record.getMessage()
        for s in (config.TELEGRAM_BOT_TOKEN, config.ANTHROPIC_API_KEY, config.SMTP["password"]):
            if s:
                msg = msg.replace(s, "***")
        record.msg, record.args = msg, ()
        return True


def format_ad(row: dict, kind: str = "new", changes: Optional[list[str]] = None, demo: bool = False) -> str:
    """HTML (Telegram) mesajı. Kullanıcıdan/ilandan gelen metinler kaçışlanır."""
    e = lambda x: html.escape(str(x if x not in (None, "") else "—"))
    import json
    reasons = json.loads(row.get("reasons") or "[]")
    warns = json.loads(row.get("warnings") or "[]")
    head = {"new": "🚆 <b>YENİ İŞ İLANI BULUNDU</b>", "priority": "🚨 <b>YÜKSEK ÖNCELİKLİ İLAN</b>",
            "update": "🔄 <b>İLAN GÜNCELLENDİ</b>", "cancel": "❌ <b>İLAN İPTAL / KAPANDI</b>",
            "reminder": "⏰ <b>SON BAŞVURU YAKLAŞIYOR</b>", "detail": "📄 <b>İLAN DETAYI</b>"}[kind]
    if demo:
        head = "🧪 [DEMO — UYDURMA ÖRNEK İLAN]\n" + head
    from analyzer import TAG_LABELS
    tag_line = " • ".join(TAG_LABELS[t] for t in (row.get("tags") or "").split() if t in TAG_LABELS)
    lines = [head, f"İlan no: #{row['id']}" if row.get("id") else "", f"Etiket: {tag_line}" if tag_line else "", f"Kurum: {e(row.get('institution'))}", f"Kadro: {e(row.get('title'))}", f"Şehir: {e(row.get('city'))}",
             f"Uygunluk puanı: {e(row.get('score'))}/100 ({e(row.get('tier'))})", f"Uygunluk durumu: {e(row.get('status'))}",
             f"Son başvuru: {e(row.get('deadline') or 'Doğrulanamadı')}"]
    if changes:
        lines += ["", "<b>Değişenler:</b>"] + [f"• {e(c)}" for c in changes[:6]]
    if reasons:
        lines += ["", "<b>Neden?</b>"] + [f"• {e(r)}" for r in reasons[:5]]
    if warns:
        lines += ["", "<b>Dikkat edilmesi gerekenler:</b>"] + [f"• {e(w)}" for w in warns[:5]]
    lines += ["", f"Resmî ilan bağlantısı: {e(row.get('url'))}", "", "<i>Başvuru otomatik yapılmaz; şartları resmî metinden teyit edin.</i>"]
    return "\n".join(lines)[:4000]


def ad_keyboard(ad_id: int) -> dict:
    cb = lambda t, s: {"text": t, "callback_data": f"st:{ad_id}:{s}"}
    return {"inline_keyboard": [[cb("⭐ Takip et", "takip"), cb("✍️ Başvuracağım", "basvuracagim")],
                                [cb("✅ Başvurdum", "basvurdum"), cb("🚫 İlgilenmiyorum", "ilgilenmiyorum")]]}


def send_telegram(text: str, retries: int = 3, session: Optional[requests.Session] = None) -> bool:
    if not (config.TELEGRAM_BOT_TOKEN and config.TELEGRAM_CHAT_ID):
        log.warning("Telegram yapılandırılmamış; mesaj gönderilmedi.")
        return False
    s = session or requests
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
    for i in range(1, retries + 1):
        try:
            payload = {"chat_id": config.TELEGRAM_CHAT_ID, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}
            mk = re.search(r"İlan no: #(\d+)", text)
            if mk:
                payload["reply_markup"] = ad_keyboard(int(mk.group(1)))
            r = s.post(url, json=payload, timeout=20)
            if r.status_code == 200:
                return True
            if r.status_code == 429:
                wait = int((r.json().get("parameters") or {}).get("retry_after", 5)) if r.headers.get("content-type", "").startswith("application/json") else 5
                time.sleep(min(wait, 30))
            elif 400 <= r.status_code < 500:
                log.error("Telegram kalıcı hata %s: %s", r.status_code, r.text[:200])
                return False
            else:
                time.sleep(2 ** i)
        except requests.RequestException as ex:
            log.warning("Telegram bağlantı hatası (%s), deneme %d/%d", type(ex).__name__, i, retries)
            time.sleep(2 ** i)
    return False


def send_email(subject: str, body: str) -> bool:
    c = config.SMTP
    if not (c["host"] and c["user"] and c["password"] and c["to"]):
        return False
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, c["user"], c["to"]
    msg.set_content(body)
    try:
        with smtplib.SMTP_SSL(c["host"], c["port"], timeout=30) as smtp:
            smtp.login(c["user"], c["password"])
            smtp.send_message(msg)
        return True
    except Exception as e:
        log.error("E-posta gönderilemedi: %s", type(e).__name__)
        return False


def notify(text: str, subject: str = "İş İlanı Takip") -> bool:
    """Önce Telegram; olmazsa e-posta. En az biri başarılıysa True."""
    if send_telegram(text):
        return True
    return send_email(subject, re.sub(r"<[^>]+>", "", html.unescape(text)))
