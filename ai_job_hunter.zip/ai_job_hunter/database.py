"""SQLite veritabanı: ilan geçmişi, değişiklik kaydı, bildirim durumu, kaynak sağlığı, yedekleme, çalışma kilidi."""
from __future__ import annotations

import difflib
import hashlib
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

import config
from analyzer import fold

SCHEMA = """
CREATE TABLE IF NOT EXISTS ads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fingerprint TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL,
  source_id TEXT,
  institution TEXT, title TEXT, city TEXT, category TEXT DEFAULT 'kamu',
  url TEXT,
  first_seen TEXT NOT NULL, last_checked TEXT NOT NULL, updated_at TEXT NOT NULL,
  start_date TEXT, deadline TEXT,
  score INTEGER, tier TEXT, status TEXT, reasons TEXT, warnings TEXT,
  lifecycle TEXT NOT NULL DEFAULT 'active',        -- active | closed | cancelled
  content_hash TEXT, raw_text TEXT, extracted TEXT,
  notified INTEGER NOT NULL DEFAULT 0, notified_at TEXT, notified_hash TEXT,
  user_status TEXT DEFAULT NULL                     -- takip | basvuracagim | basvurdum | ilgilenmiyorum | sonuc_bekliyorum
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_source ON ads(source, source_id) WHERE source_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS changes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ad_id INTEGER NOT NULL, at TEXT NOT NULL, field TEXT, old TEXT, new TEXT);
CREATE TABLE IF NOT EXISTS reminders (ad_id INTEGER NOT NULL, kind TEXT NOT NULL, sent_at TEXT NOT NULL, PRIMARY KEY (ad_id, kind));
CREATE TABLE IF NOT EXISTS source_health (
  source TEXT PRIMARY KEY, consecutive_failures INTEGER NOT NULL DEFAULT 0, last_ok TEXT, last_error TEXT, alerted INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS guide_rows (
  guide TEXT NOT NULL, osym_code TEXT NOT NULL, institution TEXT, employment TEXT, title TEXT, city TEXT, place TEXT, quota INTEGER,
  codes TEXT, edu_ok INTEGER DEFAULT 0, generic INTEGER DEFAULT 0, prio INTEGER DEFAULT 2, PRIMARY KEY (guide, osym_code));
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, started TEXT, finished TEXT, new_ads INTEGER, updated_ads INTEGER,
  notified INTEGER, errors TEXT);
"""
TRACKED_FIELDS = ["title", "city", "deadline", "start_date", "status", "lifecycle", "url"]


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def make_fingerprint(institution: str, title: str, city: str) -> str:
    """URL'den bağımsız parmak izi: kurum + unvan + şehir (diakritik/boşluk/rakam-tarih farkları yok sayılır)."""
    norm = re.sub(r"[^a-z0-9]+", " ", fold(f"{institution}|{title}|{city}"))
    return hashlib.sha1(norm.strip().encode()).hexdigest()


def content_hash(text: str) -> str:
    return hashlib.sha1(re.sub(r"\s+", " ", fold(text)).strip().encode()).hexdigest()


class DB:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path or config.DB_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(SCHEMA)
        cols = [r[1] for r in self.conn.execute("PRAGMA table_info(ads)")]
        if "tags" not in cols:  # eski veritabanlarını yükselt
            self.conn.execute("ALTER TABLE ads ADD COLUMN tags TEXT")
        self.conn.commit()

    def close(self):
        self.conn.close()

    # ------------------------------------------------------------------ eşleştirme
    def find_existing(self, source: str, source_id: Optional[str], institution: str, title: str, city: str) -> Optional[sqlite3.Row]:
        """1) (kaynak, kaynak_id)  2) parmak izi  3) aynı kurumda çok benzer başlık (URL değişse de aynı ilan)."""
        c = self.conn
        if source_id:
            r = c.execute("SELECT * FROM ads WHERE source=? AND source_id=?", (source, source_id)).fetchone()
            if r:
                return r
        fp = make_fingerprint(institution, title, city)
        r = c.execute("SELECT * FROM ads WHERE fingerprint=?", (fp,)).fetchone()
        if r:
            return r
        cand = c.execute("SELECT * FROM ads WHERE source=? AND lifecycle='active'", (source,)).fetchall()
        ft = fold(title)
        for r in cand:
            if fold(r["institution"] or "") == fold(institution) and fold(r["city"] or "") == fold(city) \
                    and difflib.SequenceMatcher(None, fold(r["title"] or ""), ft).ratio() >= 0.93:
                return r
        return None

    # ------------------------------------------------------------------ yazma
    def upsert_ad(self, ad: dict, text: str) -> tuple[sqlite3.Row, str]:
        """İlanı ekler/günceller. Döner: (satır, 'new'|'changed'|'same'). Değişen alanlar 'changes' tablosuna yazılır."""
        h = content_hash(text) if text else None
        t = now()
        with self.tx() as c:
            ex = self.find_existing(ad["source"], ad.get("source_id"), ad.get("institution", ""), ad.get("title", ""), ad.get("city", ""))
            if ex is None:
                fp = make_fingerprint(ad.get("institution", ""), ad.get("title", ""), ad.get("city", ""))
                c.execute("""INSERT INTO ads (fingerprint,source,source_id,institution,title,city,category,url,first_seen,last_checked,updated_at,content_hash,raw_text)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (fp, ad["source"], ad.get("source_id"), ad.get("institution"), ad.get("title"), ad.get("city"),
                           ad.get("category", "kamu"), ad.get("url"), t, t, t, h, (text or "")[:60000]))
                row = c.execute("SELECT * FROM ads WHERE fingerprint=?", (fp,)).fetchone()
                return row, "new"
            changed = False
            if h and h != ex["content_hash"]:
                changed = True
            if ad.get("url") and ad["url"] != ex["url"]:
                c.execute("INSERT INTO changes (ad_id,at,field,old,new) VALUES (?,?,?,?,?)", (ex["id"], t, "url", ex["url"], ad["url"]))
            c.execute("UPDATE ads SET last_checked=?, url=COALESCE(?,url), source_id=COALESCE(source_id,?), content_hash=COALESCE(?,content_hash), raw_text=COALESCE(?,raw_text) WHERE id=?",
                      (t, ad.get("url"), ad.get("source_id"), h, (text or "")[:60000] if h else None, ex["id"]))
            row = c.execute("SELECT * FROM ads WHERE id=?", (ex["id"],)).fetchone()
            return row, ("changed" if changed else "same")

    def save_analysis(self, ad_id: int, res: dict, ex: dict, meta: Optional[dict] = None) -> list[str]:
        """Analiz sonucunu yazar; değişen izlenen alanları döndürür (güncelleme bildirimi için)."""
        t = now()
        meta = meta or {}
        ex = {k: v for k, v in ex.items() if not k.startswith("_")}
        lifecycle = "cancelled" if ex.get("is_cancelled") else ("closed" if res["closed"] else "active")
        new = {"title": meta.get("title"), "city": meta.get("city"), "deadline": res.get("deadline"),
               "start_date": res.get("start_date"), "status": res["status"], "lifecycle": lifecycle, "url": meta.get("url")}
        with self.tx() as c:
            old = c.execute("SELECT * FROM ads WHERE id=?", (ad_id,)).fetchone()
            diffs = []
            for f in TRACKED_FIELDS:
                nv = new.get(f)
                if nv is not None and str(nv) != str(old[f] if old[f] is not None else "") and old[f] is not None:
                    c.execute("INSERT INTO changes (ad_id,at,field,old,new) VALUES (?,?,?,?,?)", (ad_id, t, f, old[f], nv))
                    diffs.append(f"{f}: {old[f]} → {nv}")
            c.execute("""UPDATE ads SET score=?,tier=?,status=?,reasons=?,warnings=?,deadline=COALESCE(?,deadline),start_date=COALESCE(?,start_date),
                         lifecycle=?,extracted=?,updated_at=?,title=COALESCE(?,title),city=COALESCE(?,city),tags=? WHERE id=?""",
                      (res["score"], res["tier"], res["status"], json.dumps(res["reasons"] + [f"⛔ {b}" for b in res["blockers"]], ensure_ascii=False),
                       json.dumps(res["warnings"], ensure_ascii=False), res.get("deadline"), res.get("start_date"), lifecycle,
                       json.dumps(ex, ensure_ascii=False), t, meta.get("title"), meta.get("city"), " ".join(res.get("tags", [])), ad_id))
        return diffs

    def mark_notified(self, ad_id: int, content_h: Optional[str]):
        with self.tx() as c:
            c.execute("UPDATE ads SET notified=1, notified_at=?, notified_hash=? WHERE id=?", (now(), content_h, ad_id))

    def reminder_sent(self, ad_id: int, kind: str) -> bool:
        return self.conn.execute("SELECT 1 FROM reminders WHERE ad_id=? AND kind=?", (ad_id, kind)).fetchone() is not None

    def add_reminder(self, ad_id: int, kind: str):
        with self.tx() as c:
            c.execute("INSERT OR IGNORE INTO reminders VALUES (?,?,?)", (ad_id, kind, now()))

    def set_user_status(self, ad_id: int, status: Optional[str]):
        with self.tx() as c:
            c.execute("UPDATE ads SET user_status=? WHERE id=?", (status, ad_id))

    # ------------------------------------------------------------------ kaynak sağlığı
    def record_source(self, source: str, ok: bool, error: str = "") -> int:
        with self.tx() as c:
            c.execute("INSERT OR IGNORE INTO source_health (source) VALUES (?)", (source,))
            if ok:
                c.execute("UPDATE source_health SET consecutive_failures=0,last_ok=?,alerted=0 WHERE source=?", (now(), source))
                return 0
            c.execute("UPDATE source_health SET consecutive_failures=consecutive_failures+1,last_error=? WHERE source=?", (error[:300], source))
            return c.execute("SELECT consecutive_failures FROM source_health WHERE source=?", (source,)).fetchone()[0]

    def should_alert_source(self, source: str, threshold: int = 3) -> bool:
        r = self.conn.execute("SELECT consecutive_failures, alerted FROM source_health WHERE source=?", (source,)).fetchone()
        if r and r["consecutive_failures"] >= threshold and not r["alerted"]:
            with self.tx() as c:
                c.execute("UPDATE source_health SET alerted=1 WHERE source=?", (source,))
            return True
        return False

    def log_run(self, started: str, new_ads: int, updated: int, notified: int, errors: list[str]):
        with self.tx() as c:
            c.execute("INSERT INTO runs (started,finished,new_ads,updated_ads,notified,errors) VALUES (?,?,?,?,?,?)",
                      (started, now(), new_ads, updated, notified, json.dumps(errors, ensure_ascii=False)))

    # ------------------------------------------------------------------ ayarlar
    def get_setting(self, key: str, default=None):
        r = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r[0] if r else default

    def set_setting(self, key: str, value):
        with self.tx() as c:
            c.execute("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    # ------------------------------------------------------------------ yardımcılar
    @contextmanager
    def tx(self):
        try:
            self.conn.execute("BEGIN IMMEDIATE")
            yield self.conn
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def backup(self, keep: int = 14) -> Path:
        config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        dest = config.BACKUP_DIR / f"jobs_{datetime.now():%Y%m%d_%H%M%S}.db"
        b = sqlite3.connect(dest)
        with b:
            self.conn.backup(b)
        b.close()
        for old in sorted(config.BACKUP_DIR.glob("jobs_*.db"))[:-keep]:
            old.unlink(missing_ok=True)
        return dest


@contextmanager
def run_lock(path: Optional[Path] = None, stale_seconds: int = 3 * 3600):
    """Aynı anda iki çalışmayı engeller (çift kayıt/çift bildirim önlemi). Eski (takılı kalmış) kilit otomatik silinir."""
    path = Path(path or config.LOCK_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and time.time() - path.stat().st_mtime > stale_seconds:
        path.unlink(missing_ok=True)
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise RuntimeError("Başka bir çalışma sürüyor (kilit dosyası var); bu çalışma atlandı.")
    try:
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        yield
    finally:
        path.unlink(missing_ok=True)
